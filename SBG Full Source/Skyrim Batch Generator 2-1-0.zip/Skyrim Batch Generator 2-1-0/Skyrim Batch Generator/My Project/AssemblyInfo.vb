﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Skyrim Batch Generator")> 
<Assembly: AssemblyDescription("Questions? Comments? Found a bug? Let me know at the Nexus! http://www.nexusmods.com/skyrim/users/6997193/?")> 
<Assembly: AssemblyCompany("Written by David Kurtz")> 
<Assembly: AssemblyProduct("Skyrim Batch Generator")> 
<Assembly: AssemblyCopyright("")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("0795b150-da22-48b0-8493-261db63daf86")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("2.1.0.0")> 
<Assembly: AssemblyFileVersion("2.1.0.0")> 
