﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ListViewGroup1 As System.Windows.Forms.ListViewGroup = New System.Windows.Forms.ListViewGroup("ListViewGroup", System.Windows.Forms.HorizontalAlignment.Left)
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtBatchName = New System.Windows.Forms.TextBox()
        Me.txtPreview = New System.Windows.Forms.TextBox()
        Me.mnuStrip = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileCreateBatch = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileStartOver = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuMods = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerks = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombat = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArchery = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryOverdraw = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryOverdrawRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryOverdrawRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryOverdrawRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryOverdrawRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryOverdrawRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryCriticalshot = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryCriticalshotRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryCriticalshotRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryCriticalshotRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryHuntersdiscipline = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryRanger = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryEagleeye = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryPowershot = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryQuickshot = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcherySteadyhand = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcherySteadyhandRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcherySteadyhandRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatArcheryBullseye = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlocking = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingShieldwall = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingShieldwallRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingShieldwallRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingShieldwallRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingShieldwallRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingShieldwallRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingDeflectarrows = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingElementalprotection = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingBlockrunner = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingPowerbash = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingDeadlybash = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingDisarmingbash = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingShieldcharge = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatBlockingQuickreflexes = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorJuggernaut = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorFistsofsteel = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorCushioned = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorConditioning = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorWellfitted = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorTowerofstrength = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorMatchingset = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatHeavyarmorReflectblows = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatOnehanded = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedArmsman = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedBladesman = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedBonebreaker = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedDualflurry = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedDualsavagery = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedFightingstance = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedCriticalcharge = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedSavagestrike = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedParalyzingstrike = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedHackandslash = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatSmithing = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingSteel = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingArcane = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingDwarven = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingOrcish = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingEbony = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingDaedric = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingElven = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingAdvanced = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingGlass = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatSmithingDragon = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksCombatTwohanded = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedBarbarian = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedChampionstance = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedDevastatingblow = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedGreatcritcharge = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedSweep = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedWarmaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedDeepwounds = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedLimbsplitter = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedSkullcrusher = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksStealth = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemy = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyAlchemist = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyPhysician = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyBenefactor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyExperimenter = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyPoisoner = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyConcpoison = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyGreenthumb = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemySnakeblood = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthAlchemyPurity = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorAgiledefender = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorCustomfit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorMatchset = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorUnhindered = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorWind = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLightarmorDeftmove = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpicking = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingNovice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingApprentice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingQuickhands = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingWaxkey = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingAdept = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingExpert = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingGoldtouch = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingTreasure = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingLocksmith = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingUnbreakable = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthLockpickingMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocket = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketLightfingers = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketNight = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketCutpurse = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketKeymaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketMisdirection = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketPerfecttouch = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketExtrapockets = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthPickpocketPoisoned = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneak = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakStealth = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakStealthRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakStealthRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakStealthRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakStealthRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakStealthRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakBackstab = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakDeadlyaim = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakAssblade = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakMufflemove = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakLightfoot = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakSilentroll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakSilence = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSneakShadow = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeech = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechHaggle = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechHaggleRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechHaggleRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechHaggleRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechHaggleRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechHaggleRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechAllure = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechMerchant = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechInvestor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechFence = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechBribe = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechPersuasion = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksStealthSpeechIntimidation = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksMagic = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlteration = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationNovice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationDual = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationApprentice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMagicresist = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMagicresistRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMagicresistRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMagicresistRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationAdept = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationExpert = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationAtronach = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationStability = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMagearmor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMagearmorRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMagearmorRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicAlterationMagearmorRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjuration = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationNovice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationApprentice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationAdept = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationExpert = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationDual = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationMysticbind = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationSoulsteal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationOblivbind = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationNecro = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationDark = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationSummoner = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationSummonerRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationSummonerRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationAtro = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationPotency = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicConjurationTwin = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestruction = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionNovice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionApprentice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAdept = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionExpert = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionRune = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentflame = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionIntenseflame = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentfrost = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionDeepfreeze = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentshock = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionDisintigrate = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionDualcast = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicDestructionImpact = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchanting = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingEnchanter = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingFire = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingFrost = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingStorm = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingInsight = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingCorpus = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingExtra = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingSoulsqueeze = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicEnchantingSoulsiphon = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusion = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionNovice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionAnimage = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionKindred = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionQuiet = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionApprentice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionAdept = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionExpert = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionHypnotic = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionAspectterror = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionRage = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionMastermind = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicIllusionDual = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestoration = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationNovice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationApprentice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationAdept = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationExpert = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationMaster = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationRecovery = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationRecoveryRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationRecoveryRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationAvoiddeath = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationRegen = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationNecro = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationRespite = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationDual = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersPerksMagicRestorationWardabsorb = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsCharlevel = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsGold = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsGoldAdd = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsGoldRemove = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsHealth = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsMagicka = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShouts = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanilla = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaAnimal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaAura = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaEthereal = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaCalldragon = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaCallvalor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaClearskies = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaDisarm = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaDismay = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaDragonrend = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaElementalfury = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaFirebreath = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaFrostbreath = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaIceform = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaKynes = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaMarked = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaSlow = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaStorm = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaThrow = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaForce = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsVanillaSprint = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsDawnguard = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsShoutsDragonborn = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsSkills = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsGroups = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsGroupsAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsGroupsCombat = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsGroupsStealth = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsGroupsMagic = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecific = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificCombat = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificCombatArchery = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificCombatBlock = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificCombatHeavyarmor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificCombatOnehanded = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificCombatSmithing = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificCombatTwohanded = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificStealth = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificStealthAlchemy = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificStealthLightarmor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificStealthLockpicking = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificStealthPickpocket = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificStealthSneak = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificStealthSpeech = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificMagic = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificMagicAlteration = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificMagicConjuration = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificMagicDestruction = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificMagicEnchanting = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificMagicIllusion = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersSkillsSpecificMagicRestoration = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsStamina = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsStone = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneApprentice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneAtronach = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneLady = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneLord = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneLover = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneMage = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneRitual = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneSerpent = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneShadow = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneSteed = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneThief = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneTower = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModifiersStoneWarrior = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModes = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModesStandard = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModesAdvanced = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDLC = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDLCVanilla = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDLCDawnguard = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDLCDragonborn = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpInstructions = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListView = New System.Windows.Forms.ListView()
        Me.lvwCode = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lvwDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.mnuModsPerksWerewolf = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfBestialstrength = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfAnimalvigor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfGorging = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfSavagefeeding = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfTotemice = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfTotemmoon = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfTotemterror = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfTotempredator = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfBestialstrengthRank1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfBestialstrengthRank2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfBestialstrengthRank3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuModsPerksWerewolfBestialstrengthRank4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(149, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "The Batch File will be named: "
        '
        'txtBatchName
        '
        Me.txtBatchName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBatchName.Location = New System.Drawing.Point(164, 38)
        Me.txtBatchName.Name = "txtBatchName"
        Me.txtBatchName.Size = New System.Drawing.Size(100, 20)
        Me.txtBatchName.TabIndex = 7
        '
        'txtPreview
        '
        Me.txtPreview.Location = New System.Drawing.Point(12, 64)
        Me.txtPreview.Multiline = True
        Me.txtPreview.Name = "txtPreview"
        Me.txtPreview.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtPreview.Size = New System.Drawing.Size(317, 298)
        Me.txtPreview.TabIndex = 15
        Me.txtPreview.TabStop = False
        Me.txtPreview.Visible = False
        Me.txtPreview.WordWrap = False
        '
        'mnuStrip
        '
        Me.mnuStrip.BackColor = System.Drawing.SystemColors.ControlDark
        Me.mnuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuMods, Me.mnuModes, Me.mnuDLC, Me.mnuHelp})
        Me.mnuStrip.Location = New System.Drawing.Point(0, 0)
        Me.mnuStrip.Name = "mnuStrip"
        Me.mnuStrip.Size = New System.Drawing.Size(341, 24)
        Me.mnuStrip.TabIndex = 19
        Me.mnuStrip.Text = "mnuStrip"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileCreateBatch, Me.mnuFileStartOver, Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuFileCreateBatch
        '
        Me.mnuFileCreateBatch.Name = "mnuFileCreateBatch"
        Me.mnuFileCreateBatch.Size = New System.Drawing.Size(144, 22)
        Me.mnuFileCreateBatch.Text = "Create Batch!"
        '
        'mnuFileStartOver
        '
        Me.mnuFileStartOver.Name = "mnuFileStartOver"
        Me.mnuFileStartOver.Size = New System.Drawing.Size(144, 22)
        Me.mnuFileStartOver.Text = "Start Over"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(144, 22)
        Me.mnuFileExit.Text = "Exit"
        '
        'mnuMods
        '
        Me.mnuMods.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsCharlevel, Me.mnuModsGold, Me.mnuModsHealth, Me.mnuModsMagicka, Me.mnuModsPerks, Me.mnuModsShouts, Me.mnuModsSkills, Me.mnuModsStamina, Me.mnuModsStone})
        Me.mnuMods.Name = "mnuMods"
        Me.mnuMods.Size = New System.Drawing.Size(69, 20)
        Me.mnuMods.Text = "Modifiers"
        '
        'mnuModsPerks
        '
        Me.mnuModsPerks.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombat, Me.mnuModsPerksStealth, Me.mnuModsPerksMagic, Me.mnuModsPerksWerewolf})
        Me.mnuModsPerks.Name = "mnuModsPerks"
        Me.mnuModsPerks.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsPerks.Text = "Perks"
        '
        'mnuModsPerksCombat
        '
        Me.mnuModsPerksCombat.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatArchery, Me.mnuModsPerksCombatBlocking, Me.mnuModsPerksCombatHeavyarmor, Me.mnuModsPerksCombatOnehanded, Me.mnuModsPerksCombatSmithing, Me.mnuModsPerksCombatTwohanded})
        Me.mnuModsPerksCombat.Name = "mnuModsPerksCombat"
        Me.mnuModsPerksCombat.Size = New System.Drawing.Size(196, 22)
        Me.mnuModsPerksCombat.Text = "Combat"
        '
        'mnuModsPerksCombatArchery
        '
        Me.mnuModsPerksCombatArchery.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatArcheryOverdraw, Me.mnuModsPerksCombatArcheryCriticalshot, Me.mnuModsPerksCombatArcheryHuntersdiscipline, Me.mnuModsPerksCombatArcheryRanger, Me.mnuModsPerksCombatArcheryEagleeye, Me.mnuModsPerksCombatArcheryPowershot, Me.mnuModsPerksCombatArcheryQuickshot, Me.mnuModsPerksCombatArcherySteadyhand, Me.mnuModsPerksCombatArcheryBullseye})
        Me.mnuModsPerksCombatArchery.Name = "mnuModsPerksCombatArchery"
        Me.mnuModsPerksCombatArchery.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsPerksCombatArchery.Text = "Archery"
        '
        'mnuModsPerksCombatArcheryOverdraw
        '
        Me.mnuModsPerksCombatArcheryOverdraw.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatArcheryOverdrawRank1, Me.mnuModsPerksCombatArcheryOverdrawRank2, Me.mnuModsPerksCombatArcheryOverdrawRank3, Me.mnuModsPerksCombatArcheryOverdrawRank4, Me.mnuModsPerksCombatArcheryOverdrawRank5})
        Me.mnuModsPerksCombatArcheryOverdraw.Name = "mnuModsPerksCombatArcheryOverdraw"
        Me.mnuModsPerksCombatArcheryOverdraw.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcheryOverdraw.Text = "Overdraw"
        '
        'mnuModsPerksCombatArcheryOverdrawRank1
        '
        Me.mnuModsPerksCombatArcheryOverdrawRank1.Name = "mnuModsPerksCombatArcheryOverdrawRank1"
        Me.mnuModsPerksCombatArcheryOverdrawRank1.Size = New System.Drawing.Size(163, 22)
        Me.mnuModsPerksCombatArcheryOverdrawRank1.Tag = "babed"
        Me.mnuModsPerksCombatArcheryOverdrawRank1.Text = "Overdraw Rank 1"
        '
        'mnuModsPerksCombatArcheryOverdrawRank2
        '
        Me.mnuModsPerksCombatArcheryOverdrawRank2.Name = "mnuModsPerksCombatArcheryOverdrawRank2"
        Me.mnuModsPerksCombatArcheryOverdrawRank2.Size = New System.Drawing.Size(163, 22)
        Me.mnuModsPerksCombatArcheryOverdrawRank2.Tag = "7934a"
        Me.mnuModsPerksCombatArcheryOverdrawRank2.Text = "Overdraw Rank 2"
        '
        'mnuModsPerksCombatArcheryOverdrawRank3
        '
        Me.mnuModsPerksCombatArcheryOverdrawRank3.Name = "mnuModsPerksCombatArcheryOverdrawRank3"
        Me.mnuModsPerksCombatArcheryOverdrawRank3.Size = New System.Drawing.Size(163, 22)
        Me.mnuModsPerksCombatArcheryOverdrawRank3.Tag = "7934b"
        Me.mnuModsPerksCombatArcheryOverdrawRank3.Text = "Overdraw Rank 3"
        '
        'mnuModsPerksCombatArcheryOverdrawRank4
        '
        Me.mnuModsPerksCombatArcheryOverdrawRank4.Name = "mnuModsPerksCombatArcheryOverdrawRank4"
        Me.mnuModsPerksCombatArcheryOverdrawRank4.Size = New System.Drawing.Size(163, 22)
        Me.mnuModsPerksCombatArcheryOverdrawRank4.Tag = "7934d"
        Me.mnuModsPerksCombatArcheryOverdrawRank4.Text = "Overdraw Rank 4"
        '
        'mnuModsPerksCombatArcheryOverdrawRank5
        '
        Me.mnuModsPerksCombatArcheryOverdrawRank5.Name = "mnuModsPerksCombatArcheryOverdrawRank5"
        Me.mnuModsPerksCombatArcheryOverdrawRank5.Size = New System.Drawing.Size(163, 22)
        Me.mnuModsPerksCombatArcheryOverdrawRank5.Tag = "79354"
        Me.mnuModsPerksCombatArcheryOverdrawRank5.Text = "Overdraw Rank 5"
        '
        'mnuModsPerksCombatArcheryCriticalshot
        '
        Me.mnuModsPerksCombatArcheryCriticalshot.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatArcheryCriticalshotRank1, Me.mnuModsPerksCombatArcheryCriticalshotRank2, Me.mnuModsPerksCombatArcheryCriticalshotRank3})
        Me.mnuModsPerksCombatArcheryCriticalshot.Name = "mnuModsPerksCombatArcheryCriticalshot"
        Me.mnuModsPerksCombatArcheryCriticalshot.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcheryCriticalshot.Text = "Critical Shot"
        '
        'mnuModsPerksCombatArcheryCriticalshotRank1
        '
        Me.mnuModsPerksCombatArcheryCriticalshotRank1.Name = "mnuModsPerksCombatArcheryCriticalshotRank1"
        Me.mnuModsPerksCombatArcheryCriticalshotRank1.Size = New System.Drawing.Size(176, 22)
        Me.mnuModsPerksCombatArcheryCriticalshotRank1.Tag = "105f1c"
        Me.mnuModsPerksCombatArcheryCriticalshotRank1.Text = "Critical Shot Rank 1"
        '
        'mnuModsPerksCombatArcheryCriticalshotRank2
        '
        Me.mnuModsPerksCombatArcheryCriticalshotRank2.Name = "mnuModsPerksCombatArcheryCriticalshotRank2"
        Me.mnuModsPerksCombatArcheryCriticalshotRank2.Size = New System.Drawing.Size(176, 22)
        Me.mnuModsPerksCombatArcheryCriticalshotRank2.Tag = "105f1e"
        Me.mnuModsPerksCombatArcheryCriticalshotRank2.Text = "Critical Shot Rank 2"
        '
        'mnuModsPerksCombatArcheryCriticalshotRank3
        '
        Me.mnuModsPerksCombatArcheryCriticalshotRank3.Name = "mnuModsPerksCombatArcheryCriticalshotRank3"
        Me.mnuModsPerksCombatArcheryCriticalshotRank3.Size = New System.Drawing.Size(176, 22)
        Me.mnuModsPerksCombatArcheryCriticalshotRank3.Tag = "105f1f"
        Me.mnuModsPerksCombatArcheryCriticalshotRank3.Text = "Critical Shot Rank 3"
        '
        'mnuModsPerksCombatArcheryHuntersdiscipline
        '
        Me.mnuModsPerksCombatArcheryHuntersdiscipline.Name = "mnuModsPerksCombatArcheryHuntersdiscipline"
        Me.mnuModsPerksCombatArcheryHuntersdiscipline.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcheryHuntersdiscipline.Tag = "51b12"
        Me.mnuModsPerksCombatArcheryHuntersdiscipline.Text = "Hunter's Discipline"
        '
        'mnuModsPerksCombatArcheryRanger
        '
        Me.mnuModsPerksCombatArcheryRanger.Name = "mnuModsPerksCombatArcheryRanger"
        Me.mnuModsPerksCombatArcheryRanger.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcheryRanger.Tag = "58f63"
        Me.mnuModsPerksCombatArcheryRanger.Text = "Ranger"
        '
        'mnuModsPerksCombatArcheryEagleeye
        '
        Me.mnuModsPerksCombatArcheryEagleeye.Name = "mnuModsPerksCombatArcheryEagleeye"
        Me.mnuModsPerksCombatArcheryEagleeye.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcheryEagleeye.Tag = "58f61"
        Me.mnuModsPerksCombatArcheryEagleeye.Text = "Eagle Eye"
        '
        'mnuModsPerksCombatArcheryPowershot
        '
        Me.mnuModsPerksCombatArcheryPowershot.Name = "mnuModsPerksCombatArcheryPowershot"
        Me.mnuModsPerksCombatArcheryPowershot.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcheryPowershot.Tag = "58f62"
        Me.mnuModsPerksCombatArcheryPowershot.Text = "Power Shot"
        '
        'mnuModsPerksCombatArcheryQuickshot
        '
        Me.mnuModsPerksCombatArcheryQuickshot.Name = "mnuModsPerksCombatArcheryQuickshot"
        Me.mnuModsPerksCombatArcheryQuickshot.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcheryQuickshot.Tag = "105f19"
        Me.mnuModsPerksCombatArcheryQuickshot.Text = "Quick Shot"
        '
        'mnuModsPerksCombatArcherySteadyhand
        '
        Me.mnuModsPerksCombatArcherySteadyhand.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatArcherySteadyhandRank1, Me.mnuModsPerksCombatArcherySteadyhandRank2})
        Me.mnuModsPerksCombatArcherySteadyhand.Name = "mnuModsPerksCombatArcherySteadyhand"
        Me.mnuModsPerksCombatArcherySteadyhand.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcherySteadyhand.Text = "Steady Hand"
        '
        'mnuModsPerksCombatArcherySteadyhandRank1
        '
        Me.mnuModsPerksCombatArcherySteadyhandRank1.Name = "mnuModsPerksCombatArcherySteadyhandRank1"
        Me.mnuModsPerksCombatArcherySteadyhandRank1.Size = New System.Drawing.Size(179, 22)
        Me.mnuModsPerksCombatArcherySteadyhandRank1.Tag = "103ada"
        Me.mnuModsPerksCombatArcherySteadyhandRank1.Text = "Steady Hand Rank 1"
        '
        'mnuModsPerksCombatArcherySteadyhandRank2
        '
        Me.mnuModsPerksCombatArcherySteadyhandRank2.Name = "mnuModsPerksCombatArcherySteadyhandRank2"
        Me.mnuModsPerksCombatArcherySteadyhandRank2.Size = New System.Drawing.Size(179, 22)
        Me.mnuModsPerksCombatArcherySteadyhandRank2.Tag = "103adb"
        Me.mnuModsPerksCombatArcherySteadyhandRank2.Text = "Steady Hand Rank 2"
        '
        'mnuModsPerksCombatArcheryBullseye
        '
        Me.mnuModsPerksCombatArcheryBullseye.Name = "mnuModsPerksCombatArcheryBullseye"
        Me.mnuModsPerksCombatArcheryBullseye.Size = New System.Drawing.Size(173, 22)
        Me.mnuModsPerksCombatArcheryBullseye.Tag = "58f64"
        Me.mnuModsPerksCombatArcheryBullseye.Text = "Bullseye"
        '
        'mnuModsPerksCombatBlocking
        '
        Me.mnuModsPerksCombatBlocking.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatBlockingShieldwall, Me.mnuModsPerksCombatBlockingDeflectarrows, Me.mnuModsPerksCombatBlockingElementalprotection, Me.mnuModsPerksCombatBlockingBlockrunner, Me.mnuModsPerksCombatBlockingPowerbash, Me.mnuModsPerksCombatBlockingDeadlybash, Me.mnuModsPerksCombatBlockingDisarmingbash, Me.mnuModsPerksCombatBlockingShieldcharge, Me.mnuModsPerksCombatBlockingQuickreflexes})
        Me.mnuModsPerksCombatBlocking.Name = "mnuModsPerksCombatBlocking"
        Me.mnuModsPerksCombatBlocking.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsPerksCombatBlocking.Text = "Blocking"
        '
        'mnuModsPerksCombatBlockingShieldwall
        '
        Me.mnuModsPerksCombatBlockingShieldwall.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatBlockingShieldwallRank1, Me.mnuModsPerksCombatBlockingShieldwallRank2, Me.mnuModsPerksCombatBlockingShieldwallRank3, Me.mnuModsPerksCombatBlockingShieldwallRank4, Me.mnuModsPerksCombatBlockingShieldwallRank5})
        Me.mnuModsPerksCombatBlockingShieldwall.Name = "mnuModsPerksCombatBlockingShieldwall"
        Me.mnuModsPerksCombatBlockingShieldwall.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingShieldwall.Text = "Shield Wall"
        '
        'mnuModsPerksCombatBlockingShieldwallRank1
        '
        Me.mnuModsPerksCombatBlockingShieldwallRank1.Name = "mnuModsPerksCombatBlockingShieldwallRank1"
        Me.mnuModsPerksCombatBlockingShieldwallRank1.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsPerksCombatBlockingShieldwallRank1.Tag = "bccae"
        Me.mnuModsPerksCombatBlockingShieldwallRank1.Text = "Shield Wall Rank 1"
        '
        'mnuModsPerksCombatBlockingShieldwallRank2
        '
        Me.mnuModsPerksCombatBlockingShieldwallRank2.Name = "mnuModsPerksCombatBlockingShieldwallRank2"
        Me.mnuModsPerksCombatBlockingShieldwallRank2.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsPerksCombatBlockingShieldwallRank2.Tag = "79355"
        Me.mnuModsPerksCombatBlockingShieldwallRank2.Text = "Shield Wall Rank 2"
        '
        'mnuModsPerksCombatBlockingShieldwallRank3
        '
        Me.mnuModsPerksCombatBlockingShieldwallRank3.Name = "mnuModsPerksCombatBlockingShieldwallRank3"
        Me.mnuModsPerksCombatBlockingShieldwallRank3.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsPerksCombatBlockingShieldwallRank3.Tag = "79356"
        Me.mnuModsPerksCombatBlockingShieldwallRank3.Text = "Shield Wall Rank 3"
        '
        'mnuModsPerksCombatBlockingShieldwallRank4
        '
        Me.mnuModsPerksCombatBlockingShieldwallRank4.Name = "mnuModsPerksCombatBlockingShieldwallRank4"
        Me.mnuModsPerksCombatBlockingShieldwallRank4.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsPerksCombatBlockingShieldwallRank4.Tag = "79357"
        Me.mnuModsPerksCombatBlockingShieldwallRank4.Text = "Shield Wall Rank 4"
        '
        'mnuModsPerksCombatBlockingShieldwallRank5
        '
        Me.mnuModsPerksCombatBlockingShieldwallRank5.Name = "mnuModsPerksCombatBlockingShieldwallRank5"
        Me.mnuModsPerksCombatBlockingShieldwallRank5.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsPerksCombatBlockingShieldwallRank5.Tag = "79358"
        Me.mnuModsPerksCombatBlockingShieldwallRank5.Text = "Shield Wall Rank 5"
        '
        'mnuModsPerksCombatBlockingDeflectarrows
        '
        Me.mnuModsPerksCombatBlockingDeflectarrows.Name = "mnuModsPerksCombatBlockingDeflectarrows"
        Me.mnuModsPerksCombatBlockingDeflectarrows.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingDeflectarrows.Tag = "58f68"
        Me.mnuModsPerksCombatBlockingDeflectarrows.Text = "Deflect Arrows"
        '
        'mnuModsPerksCombatBlockingElementalprotection
        '
        Me.mnuModsPerksCombatBlockingElementalprotection.Name = "mnuModsPerksCombatBlockingElementalprotection"
        Me.mnuModsPerksCombatBlockingElementalprotection.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingElementalprotection.Tag = "58f69"
        Me.mnuModsPerksCombatBlockingElementalprotection.Text = "Elemental Protection"
        '
        'mnuModsPerksCombatBlockingBlockrunner
        '
        Me.mnuModsPerksCombatBlockingBlockrunner.Name = "mnuModsPerksCombatBlockingBlockrunner"
        Me.mnuModsPerksCombatBlockingBlockrunner.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingBlockrunner.Tag = "106253"
        Me.mnuModsPerksCombatBlockingBlockrunner.Text = "Block Runner"
        '
        'mnuModsPerksCombatBlockingPowerbash
        '
        Me.mnuModsPerksCombatBlockingPowerbash.Name = "mnuModsPerksCombatBlockingPowerbash"
        Me.mnuModsPerksCombatBlockingPowerbash.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingPowerbash.Tag = "58f67"
        Me.mnuModsPerksCombatBlockingPowerbash.Text = "Power Bash"
        '
        'mnuModsPerksCombatBlockingDeadlybash
        '
        Me.mnuModsPerksCombatBlockingDeadlybash.Name = "mnuModsPerksCombatBlockingDeadlybash"
        Me.mnuModsPerksCombatBlockingDeadlybash.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingDeadlybash.Tag = "5f594"
        Me.mnuModsPerksCombatBlockingDeadlybash.Text = "Deadly Bash"
        '
        'mnuModsPerksCombatBlockingDisarmingbash
        '
        Me.mnuModsPerksCombatBlockingDisarmingbash.Name = "mnuModsPerksCombatBlockingDisarmingbash"
        Me.mnuModsPerksCombatBlockingDisarmingbash.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingDisarmingbash.Tag = "58f66"
        Me.mnuModsPerksCombatBlockingDisarmingbash.Text = "Disarming Bash"
        '
        'mnuModsPerksCombatBlockingShieldcharge
        '
        Me.mnuModsPerksCombatBlockingShieldcharge.Name = "mnuModsPerksCombatBlockingShieldcharge"
        Me.mnuModsPerksCombatBlockingShieldcharge.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingShieldcharge.Tag = "58f6a"
        Me.mnuModsPerksCombatBlockingShieldcharge.Text = "Shield Charge"
        '
        'mnuModsPerksCombatBlockingQuickreflexes
        '
        Me.mnuModsPerksCombatBlockingQuickreflexes.Name = "mnuModsPerksCombatBlockingQuickreflexes"
        Me.mnuModsPerksCombatBlockingQuickreflexes.Size = New System.Drawing.Size(184, 22)
        Me.mnuModsPerksCombatBlockingQuickreflexes.Tag = "d8c33"
        Me.mnuModsPerksCombatBlockingQuickreflexes.Text = "Quick Reflexes"
        '
        'mnuModsPerksCombatHeavyarmor
        '
        Me.mnuModsPerksCombatHeavyarmor.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatHeavyarmorJuggernaut, Me.mnuModsPerksCombatHeavyarmorFistsofsteel, Me.mnuModsPerksCombatHeavyarmorCushioned, Me.mnuModsPerksCombatHeavyarmorConditioning, Me.mnuModsPerksCombatHeavyarmorWellfitted, Me.mnuModsPerksCombatHeavyarmorTowerofstrength, Me.mnuModsPerksCombatHeavyarmorMatchingset, Me.mnuModsPerksCombatHeavyarmorReflectblows})
        Me.mnuModsPerksCombatHeavyarmor.Name = "mnuModsPerksCombatHeavyarmor"
        Me.mnuModsPerksCombatHeavyarmor.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsPerksCombatHeavyarmor.Text = "Heavy Armor"
        '
        'mnuModsPerksCombatHeavyarmorJuggernaut
        '
        Me.mnuModsPerksCombatHeavyarmorJuggernaut.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksCombatHeavyarmorJuggernautRank1, Me.mnuModsPerksCombatHeavyarmorJuggernautRank2, Me.mnuModsPerksCombatHeavyarmorJuggernautRank3, Me.mnuModsPerksCombatHeavyarmorJuggernautRank4, Me.mnuModsPerksCombatHeavyarmorJuggernautRank5})
        Me.mnuModsPerksCombatHeavyarmorJuggernaut.Name = "mnuModsPerksCombatHeavyarmorJuggernaut"
        Me.mnuModsPerksCombatHeavyarmorJuggernaut.Size = New System.Drawing.Size(169, 22)
        Me.mnuModsPerksCombatHeavyarmorJuggernaut.Text = "Juggernaut"
        '
        'mnuModsPerksCombatHeavyarmorJuggernautRank1
        '
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank1.Name = "mnuModsPerksCombatHeavyarmorJuggernautRank1"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank1.Size = New System.Drawing.Size(171, 22)
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank1.Tag = "bcd2a"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank1.Text = "Juggernaut Rank 1"
        '
        'mnuModsPerksCombatHeavyarmorJuggernautRank2
        '
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank2.Name = "mnuModsPerksCombatHeavyarmorJuggernautRank2"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank2.Size = New System.Drawing.Size(171, 22)
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank2.Tag = "7935e"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank2.Text = "Juggernaut Rank 2"
        '
        'mnuModsPerksCombatHeavyarmorJuggernautRank3
        '
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank3.Name = "mnuModsPerksCombatHeavyarmorJuggernautRank3"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank3.Size = New System.Drawing.Size(171, 22)
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank3.Tag = "79361"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank3.Text = "Juggernaut Rank 3"
        '
        'mnuModsPerksCombatHeavyarmorJuggernautRank4
        '
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank4.Name = "mnuModsPerksCombatHeavyarmorJuggernautRank4"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank4.Size = New System.Drawing.Size(171, 22)
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank4.Tag = "79362"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank4.Text = "Juggernaut Rank 4"
        '
        'mnuModsPerksCombatHeavyarmorJuggernautRank5
        '
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank5.Name = "mnuModsPerksCombatHeavyarmorJuggernautRank5"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank5.Size = New System.Drawing.Size(171, 22)
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank5.Tag = "79374"
        Me.mnuModsPerksCombatHeavyarmorJuggernautRank5.Text = "Juggernaut Rank 5"
        '
        'mnuModsPerksCombatHeavyarmorFistsofsteel
        '
        Me.mnuModsPerksCombatHeavyarmorFistsofsteel.Name = "mnuModsPerksCombatHeavyarmorFistsofsteel"
        Me.mnuModsPerksCombatHeavyarmorFistsofsteel.Size = New System.Drawing.Size(169, 22)
        Me.mnuModsPerksCombatHeavyarmorFistsofsteel.Tag = "58f6e"
        Me.mnuModsPerksCombatHeavyarmorFistsofsteel.Text = "Fists of Steel"
        '
        'mnuModsPerksCombatHeavyarmorCushioned
        '
        Me.mnuModsPerksCombatHeavyarmorCushioned.Name = "mnuModsPerksCombatHeavyarmorCushioned"
        Me.mnuModsPerksCombatHeavyarmorCushioned.Size = New System.Drawing.Size(169, 22)
        Me.mnuModsPerksCombatHeavyarmorCushioned.Tag = "bcd2b"
        Me.mnuModsPerksCombatHeavyarmorCushioned.Text = "Cushioned"
        '
        'mnuModsPerksCombatHeavyarmorConditioning
        '
        Me.mnuModsPerksCombatHeavyarmorConditioning.Name = "mnuModsPerksCombatHeavyarmorConditioning"
        Me.mnuModsPerksCombatHeavyarmorConditioning.Size = New System.Drawing.Size(169, 22)
        Me.mnuModsPerksCombatHeavyarmorConditioning.Tag = "58f6d"
        Me.mnuModsPerksCombatHeavyarmorConditioning.Text = "Conditioning"
        '
        'mnuModsPerksCombatHeavyarmorWellfitted
        '
        Me.mnuModsPerksCombatHeavyarmorWellfitted.Name = "mnuModsPerksCombatHeavyarmorWellfitted"
        Me.mnuModsPerksCombatHeavyarmorWellfitted.Size = New System.Drawing.Size(169, 22)
        Me.mnuModsPerksCombatHeavyarmorWellfitted.Tag = "58f6f"
        Me.mnuModsPerksCombatHeavyarmorWellfitted.Text = "Well Fitted"
        '
        'mnuModsPerksCombatHeavyarmorTowerofstrength
        '
        Me.mnuModsPerksCombatHeavyarmorTowerofstrength.Name = "mnuModsPerksCombatHeavyarmorTowerofstrength"
        Me.mnuModsPerksCombatHeavyarmorTowerofstrength.Size = New System.Drawing.Size(169, 22)
        Me.mnuModsPerksCombatHeavyarmorTowerofstrength.Tag = "58f6c"
        Me.mnuModsPerksCombatHeavyarmorTowerofstrength.Text = "Tower of Strength"
        '
        'mnuModsPerksCombatHeavyarmorMatchingset
        '
        Me.mnuModsPerksCombatHeavyarmorMatchingset.Name = "mnuModsPerksCombatHeavyarmorMatchingset"
        Me.mnuModsPerksCombatHeavyarmorMatchingset.Size = New System.Drawing.Size(169, 22)
        Me.mnuModsPerksCombatHeavyarmorMatchingset.Tag = "107832"
        Me.mnuModsPerksCombatHeavyarmorMatchingset.Text = "Matching Set"
        '
        'mnuModsPerksCombatHeavyarmorReflectblows
        '
        Me.mnuModsPerksCombatHeavyarmorReflectblows.Name = "mnuModsPerksCombatHeavyarmorReflectblows"
        Me.mnuModsPerksCombatHeavyarmorReflectblows.Size = New System.Drawing.Size(169, 22)
        Me.mnuModsPerksCombatHeavyarmorReflectblows.Tag = "105f33"
        Me.mnuModsPerksCombatHeavyarmorReflectblows.Text = "Reflect Blows"
        '
        'mnuModsPerksCombatOnehanded
        '
        Me.mnuModsPerksCombatOnehanded.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatOnehandedArmsman, Me.mnuModifiersPerksCombatOnehandedBladesman, Me.mnuModifiersPerksCombatOnehandedBonebreaker, Me.mnuModifiersPerksCombatOnehandedDualflurry, Me.mnuModifiersPerksCombatOnehandedDualsavagery, Me.mnuModifiersPerksCombatOnehandedFightingstance, Me.mnuModifiersPerksCombatOnehandedCriticalcharge, Me.mnuModifiersPerksCombatOnehandedSavagestrike, Me.mnuModifiersPerksCombatOnehandedParalyzingstrike, Me.mnuModifiersPerksCombatOnehandedHackandslash})
        Me.mnuModsPerksCombatOnehanded.Name = "mnuModsPerksCombatOnehanded"
        Me.mnuModsPerksCombatOnehanded.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsPerksCombatOnehanded.Text = "One Handed"
        '
        'mnuModifiersPerksCombatOnehandedArmsman
        '
        Me.mnuModifiersPerksCombatOnehandedArmsman.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatOnehandedArmsmanRank1, Me.mnuModifiersPerksCombatOnehandedArmsmanRank2, Me.mnuModifiersPerksCombatOnehandedArmsmanRank3, Me.mnuModifiersPerksCombatOnehandedArmsmanRank4, Me.mnuModifiersPerksCombatOnehandedArmsmanRank5})
        Me.mnuModifiersPerksCombatOnehandedArmsman.Name = "mnuModifiersPerksCombatOnehandedArmsman"
        Me.mnuModifiersPerksCombatOnehandedArmsman.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedArmsman.Text = "Armsman"
        '
        'mnuModifiersPerksCombatOnehandedArmsmanRank1
        '
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank1.Name = "mnuModifiersPerksCombatOnehandedArmsmanRank1"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank1.Size = New System.Drawing.Size(164, 22)
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank1.Tag = "babe4"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank1.Text = "Armsman Rank 1"
        '
        'mnuModifiersPerksCombatOnehandedArmsmanRank2
        '
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank2.Name = "mnuModifiersPerksCombatOnehandedArmsmanRank2"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank2.Size = New System.Drawing.Size(164, 22)
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank2.Tag = "79343"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank2.Text = "Armsman Rank 2"
        '
        'mnuModifiersPerksCombatOnehandedArmsmanRank3
        '
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank3.Name = "mnuModifiersPerksCombatOnehandedArmsmanRank3"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank3.Size = New System.Drawing.Size(164, 22)
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank3.Tag = "79342"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank3.Text = "Armsman Rank 3"
        '
        'mnuModifiersPerksCombatOnehandedArmsmanRank4
        '
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank4.Name = "mnuModifiersPerksCombatOnehandedArmsmanRank4"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank4.Size = New System.Drawing.Size(164, 22)
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank4.Tag = "79344"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank4.Text = "Armsman Rank 4"
        '
        'mnuModifiersPerksCombatOnehandedArmsmanRank5
        '
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank5.Name = "mnuModifiersPerksCombatOnehandedArmsmanRank5"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank5.Size = New System.Drawing.Size(164, 22)
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank5.Tag = "79345"
        Me.mnuModifiersPerksCombatOnehandedArmsmanRank5.Text = "Armsman Rank 5"
        '
        'mnuModifiersPerksCombatOnehandedBladesman
        '
        Me.mnuModifiersPerksCombatOnehandedBladesman.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatOnehandedBladesmanRank1, Me.mnuModifiersPerksCombatOnehandedBladesmanRank2, Me.mnuModifiersPerksCombatOnehandedBladesmanRank3})
        Me.mnuModifiersPerksCombatOnehandedBladesman.Name = "mnuModifiersPerksCombatOnehandedBladesman"
        Me.mnuModifiersPerksCombatOnehandedBladesman.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedBladesman.Text = "Bladesman"
        '
        'mnuModifiersPerksCombatOnehandedBladesmanRank1
        '
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank1.Name = "mnuModifiersPerksCombatOnehandedBladesmanRank1"
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank1.Size = New System.Drawing.Size(170, 22)
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank1.Tag = "5f56f"
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank1.Text = "Bladesman Rank 1"
        '
        'mnuModifiersPerksCombatOnehandedBladesmanRank2
        '
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank2.Name = "mnuModifiersPerksCombatOnehandedBladesmanRank2"
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank2.Size = New System.Drawing.Size(170, 22)
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank2.Tag = "c1e90"
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank2.Text = "Bladesman Rank 2"
        '
        'mnuModifiersPerksCombatOnehandedBladesmanRank3
        '
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank3.Name = "mnuModifiersPerksCombatOnehandedBladesmanRank3"
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank3.Size = New System.Drawing.Size(170, 22)
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank3.Tag = "c1e91"
        Me.mnuModifiersPerksCombatOnehandedBladesmanRank3.Text = "Bladesman Rank 3"
        '
        'mnuModifiersPerksCombatOnehandedBonebreaker
        '
        Me.mnuModifiersPerksCombatOnehandedBonebreaker.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatOnehandedBonebreakerRank1, Me.mnuModifiersPerksCombatOnehandedBonebreakerRank2, Me.mnuModifiersPerksCombatOnehandedBonebreakerRank3})
        Me.mnuModifiersPerksCombatOnehandedBonebreaker.Name = "mnuModifiersPerksCombatOnehandedBonebreaker"
        Me.mnuModifiersPerksCombatOnehandedBonebreaker.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedBonebreaker.Text = "Bone Breaker"
        '
        'mnuModifiersPerksCombatOnehandedBonebreakerRank1
        '
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank1.Name = "mnuModifiersPerksCombatOnehandedBonebreakerRank1"
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank1.Size = New System.Drawing.Size(181, 22)
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank1.Tag = "5f592"
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank1.Text = "Bone Breaker Rank 1"
        '
        'mnuModifiersPerksCombatOnehandedBonebreakerRank2
        '
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank2.Name = "mnuModifiersPerksCombatOnehandedBonebreakerRank2"
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank2.Size = New System.Drawing.Size(181, 22)
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank2.Tag = "c1e92"
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank2.Text = "Bone Breaker Rank 2"
        '
        'mnuModifiersPerksCombatOnehandedBonebreakerRank3
        '
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank3.Name = "mnuModifiersPerksCombatOnehandedBonebreakerRank3"
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank3.Size = New System.Drawing.Size(181, 22)
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank3.Tag = "c1e93"
        Me.mnuModifiersPerksCombatOnehandedBonebreakerRank3.Text = "Bone Breaker Rank 3"
        '
        'mnuModifiersPerksCombatOnehandedDualflurry
        '
        Me.mnuModifiersPerksCombatOnehandedDualflurry.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatOnehandedDualflurryRank1, Me.mnuModifiersPerksCombatOnehandedDualflurryRank2})
        Me.mnuModifiersPerksCombatOnehandedDualflurry.Name = "mnuModifiersPerksCombatOnehandedDualflurry"
        Me.mnuModifiersPerksCombatOnehandedDualflurry.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedDualflurry.Text = "Dual Flurry"
        '
        'mnuModifiersPerksCombatOnehandedDualflurryRank1
        '
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank1.Name = "mnuModifiersPerksCombatOnehandedDualflurryRank1"
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank1.Size = New System.Drawing.Size(169, 22)
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank1.Tag = "106256"
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank1.Text = "Dual Flurry Rank 1"
        '
        'mnuModifiersPerksCombatOnehandedDualflurryRank2
        '
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank2.Name = "mnuModifiersPerksCombatOnehandedDualflurryRank2"
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank2.Size = New System.Drawing.Size(169, 22)
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank2.Tag = "106257"
        Me.mnuModifiersPerksCombatOnehandedDualflurryRank2.Text = "Dual Flurry Rank 2"
        '
        'mnuModifiersPerksCombatOnehandedDualsavagery
        '
        Me.mnuModifiersPerksCombatOnehandedDualsavagery.Name = "mnuModifiersPerksCombatOnehandedDualsavagery"
        Me.mnuModifiersPerksCombatOnehandedDualsavagery.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedDualsavagery.Tag = "106258"
        Me.mnuModifiersPerksCombatOnehandedDualsavagery.Text = "Dual Savagery"
        '
        'mnuModifiersPerksCombatOnehandedFightingstance
        '
        Me.mnuModifiersPerksCombatOnehandedFightingstance.Name = "mnuModifiersPerksCombatOnehandedFightingstance"
        Me.mnuModifiersPerksCombatOnehandedFightingstance.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedFightingstance.Tag = "52d50"
        Me.mnuModifiersPerksCombatOnehandedFightingstance.Text = "Fighting Stance"
        '
        'mnuModifiersPerksCombatOnehandedCriticalcharge
        '
        Me.mnuModifiersPerksCombatOnehandedCriticalcharge.Name = "mnuModifiersPerksCombatOnehandedCriticalcharge"
        Me.mnuModifiersPerksCombatOnehandedCriticalcharge.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedCriticalcharge.Tag = "cb406"
        Me.mnuModifiersPerksCombatOnehandedCriticalcharge.Text = "Critical Charge"
        '
        'mnuModifiersPerksCombatOnehandedSavagestrike
        '
        Me.mnuModifiersPerksCombatOnehandedSavagestrike.Name = "mnuModifiersPerksCombatOnehandedSavagestrike"
        Me.mnuModifiersPerksCombatOnehandedSavagestrike.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedSavagestrike.Tag = "3af81"
        Me.mnuModifiersPerksCombatOnehandedSavagestrike.Text = "Savage Strike"
        '
        'mnuModifiersPerksCombatOnehandedParalyzingstrike
        '
        Me.mnuModifiersPerksCombatOnehandedParalyzingstrike.Name = "mnuModifiersPerksCombatOnehandedParalyzingstrike"
        Me.mnuModifiersPerksCombatOnehandedParalyzingstrike.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedParalyzingstrike.Tag = "3afa6"
        Me.mnuModifiersPerksCombatOnehandedParalyzingstrike.Text = "Paralyzing Strike"
        '
        'mnuModifiersPerksCombatOnehandedHackandslash
        '
        Me.mnuModifiersPerksCombatOnehandedHackandslash.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatOnehandedHackandslashRank1, Me.mnuModifiersPerksCombatOnehandedHackandslashRank2, Me.mnuModifiersPerksCombatOnehandedHackandslashRank3})
        Me.mnuModifiersPerksCombatOnehandedHackandslash.Name = "mnuModifiersPerksCombatOnehandedHackandslash"
        Me.mnuModifiersPerksCombatOnehandedHackandslash.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksCombatOnehandedHackandslash.Text = "Hack and Slash"
        '
        'mnuModifiersPerksCombatOnehandedHackandslashRank1
        '
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank1.Name = "mnuModifiersPerksCombatOnehandedHackandslashRank1"
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank1.Size = New System.Drawing.Size(192, 22)
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank1.Tag = "3fffa"
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank1.Text = "Hack and Slash Rank 1"
        '
        'mnuModifiersPerksCombatOnehandedHackandslashRank2
        '
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank2.Name = "mnuModifiersPerksCombatOnehandedHackandslashRank2"
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank2.Size = New System.Drawing.Size(192, 22)
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank2.Tag = "c3678"
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank2.Text = "Hack and Slash Rank 2"
        '
        'mnuModifiersPerksCombatOnehandedHackandslashRank3
        '
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank3.Name = "mnuModifiersPerksCombatOnehandedHackandslashRank3"
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank3.Size = New System.Drawing.Size(192, 22)
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank3.Tag = "c3679"
        Me.mnuModifiersPerksCombatOnehandedHackandslashRank3.Text = "Hack and Slash Rank 3"
        '
        'mnuModsPerksCombatSmithing
        '
        Me.mnuModsPerksCombatSmithing.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatSmithingSteel, Me.mnuModifiersPerksCombatSmithingArcane, Me.mnuModifiersPerksCombatSmithingDwarven, Me.mnuModifiersPerksCombatSmithingOrcish, Me.mnuModifiersPerksCombatSmithingEbony, Me.mnuModifiersPerksCombatSmithingDaedric, Me.mnuModifiersPerksCombatSmithingElven, Me.mnuModifiersPerksCombatSmithingAdvanced, Me.mnuModifiersPerksCombatSmithingGlass, Me.mnuModifiersPerksCombatSmithingDragon})
        Me.mnuModsPerksCombatSmithing.Name = "mnuModsPerksCombatSmithing"
        Me.mnuModsPerksCombatSmithing.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsPerksCombatSmithing.Text = "Smithing"
        '
        'mnuModifiersPerksCombatSmithingSteel
        '
        Me.mnuModifiersPerksCombatSmithingSteel.Name = "mnuModifiersPerksCombatSmithingSteel"
        Me.mnuModifiersPerksCombatSmithingSteel.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingSteel.Tag = "cb40d"
        Me.mnuModifiersPerksCombatSmithingSteel.Text = "Steel Smithing"
        '
        'mnuModifiersPerksCombatSmithingArcane
        '
        Me.mnuModifiersPerksCombatSmithingArcane.Name = "mnuModifiersPerksCombatSmithingArcane"
        Me.mnuModifiersPerksCombatSmithingArcane.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingArcane.Tag = "5218e"
        Me.mnuModifiersPerksCombatSmithingArcane.Text = "Arcane Blacksmith"
        '
        'mnuModifiersPerksCombatSmithingDwarven
        '
        Me.mnuModifiersPerksCombatSmithingDwarven.Name = "mnuModifiersPerksCombatSmithingDwarven"
        Me.mnuModifiersPerksCombatSmithingDwarven.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingDwarven.Tag = "cb40e"
        Me.mnuModifiersPerksCombatSmithingDwarven.Text = "Dwarven Smithing"
        '
        'mnuModifiersPerksCombatSmithingOrcish
        '
        Me.mnuModifiersPerksCombatSmithingOrcish.Name = "mnuModifiersPerksCombatSmithingOrcish"
        Me.mnuModifiersPerksCombatSmithingOrcish.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingOrcish.Tag = "cb410"
        Me.mnuModifiersPerksCombatSmithingOrcish.Text = "Orcish Smithing"
        '
        'mnuModifiersPerksCombatSmithingEbony
        '
        Me.mnuModifiersPerksCombatSmithingEbony.Name = "mnuModifiersPerksCombatSmithingEbony"
        Me.mnuModifiersPerksCombatSmithingEbony.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingEbony.Tag = "cb412"
        Me.mnuModifiersPerksCombatSmithingEbony.Text = "Ebony Smithing"
        '
        'mnuModifiersPerksCombatSmithingDaedric
        '
        Me.mnuModifiersPerksCombatSmithingDaedric.Name = "mnuModifiersPerksCombatSmithingDaedric"
        Me.mnuModifiersPerksCombatSmithingDaedric.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingDaedric.Tag = "cb413"
        Me.mnuModifiersPerksCombatSmithingDaedric.Text = "Daedric Smithing"
        '
        'mnuModifiersPerksCombatSmithingElven
        '
        Me.mnuModifiersPerksCombatSmithingElven.Name = "mnuModifiersPerksCombatSmithingElven"
        Me.mnuModifiersPerksCombatSmithingElven.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingElven.Tag = "cb40f"
        Me.mnuModifiersPerksCombatSmithingElven.Text = "Elven Smithing"
        '
        'mnuModifiersPerksCombatSmithingAdvanced
        '
        Me.mnuModifiersPerksCombatSmithingAdvanced.Name = "mnuModifiersPerksCombatSmithingAdvanced"
        Me.mnuModifiersPerksCombatSmithingAdvanced.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingAdvanced.Tag = "cb414"
        Me.mnuModifiersPerksCombatSmithingAdvanced.Text = "Advanced Armors"
        '
        'mnuModifiersPerksCombatSmithingGlass
        '
        Me.mnuModifiersPerksCombatSmithingGlass.Name = "mnuModifiersPerksCombatSmithingGlass"
        Me.mnuModifiersPerksCombatSmithingGlass.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingGlass.Tag = "cb411"
        Me.mnuModifiersPerksCombatSmithingGlass.Text = "Glass Smithing"
        '
        'mnuModifiersPerksCombatSmithingDragon
        '
        Me.mnuModifiersPerksCombatSmithingDragon.Name = "mnuModifiersPerksCombatSmithingDragon"
        Me.mnuModifiersPerksCombatSmithingDragon.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersPerksCombatSmithingDragon.Tag = "52190"
        Me.mnuModifiersPerksCombatSmithingDragon.Text = "Dragon Armor"
        '
        'mnuModsPerksCombatTwohanded
        '
        Me.mnuModsPerksCombatTwohanded.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatTwohandedBarbarian, Me.mnuModifiersPerksCombatTwohandedChampionstance, Me.mnuModifiersPerksCombatTwohandedDevastatingblow, Me.mnuModifiersPerksCombatTwohandedGreatcritcharge, Me.mnuModifiersPerksCombatTwohandedSweep, Me.mnuModifiersPerksCombatTwohandedWarmaster, Me.mnuModifiersPerksCombatTwohandedDeepwounds, Me.mnuModifiersPerksCombatTwohandedLimbsplitter, Me.mnuModifiersPerksCombatTwohandedSkullcrusher})
        Me.mnuModsPerksCombatTwohanded.Name = "mnuModsPerksCombatTwohanded"
        Me.mnuModsPerksCombatTwohanded.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsPerksCombatTwohanded.Text = "Two Handed"
        '
        'mnuModifiersPerksCombatTwohandedBarbarian
        '
        Me.mnuModifiersPerksCombatTwohandedBarbarian.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatTwohandedBarbarianRank1, Me.mnuModifiersPerksCombatTwohandedBarbarianRank2, Me.mnuModifiersPerksCombatTwohandedBarbarianRank3, Me.mnuModifiersPerksCombatTwohandedBarbarianRank4, Me.mnuModifiersPerksCombatTwohandedBarbarianRank5})
        Me.mnuModifiersPerksCombatTwohandedBarbarian.Name = "mnuModifiersPerksCombatTwohandedBarbarian"
        Me.mnuModifiersPerksCombatTwohandedBarbarian.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedBarbarian.Text = "Barbarian"
        '
        'mnuModifiersPerksCombatTwohandedBarbarianRank1
        '
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank1.Name = "mnuModifiersPerksCombatTwohandedBarbarianRank1"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank1.Size = New System.Drawing.Size(162, 22)
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank1.Tag = "babe8"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank1.Text = "Barbarian Rank 1"
        '
        'mnuModifiersPerksCombatTwohandedBarbarianRank2
        '
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank2.Name = "mnuModifiersPerksCombatTwohandedBarbarianRank2"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank2.Size = New System.Drawing.Size(162, 22)
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank2.Tag = "79346"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank2.Text = "Barbarian Rank 2"
        '
        'mnuModifiersPerksCombatTwohandedBarbarianRank3
        '
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank3.Name = "mnuModifiersPerksCombatTwohandedBarbarianRank3"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank3.Size = New System.Drawing.Size(162, 22)
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank3.Tag = "79347"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank3.Text = "Barbarian Rank 3"
        '
        'mnuModifiersPerksCombatTwohandedBarbarianRank4
        '
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank4.Name = "mnuModifiersPerksCombatTwohandedBarbarianRank4"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank4.Size = New System.Drawing.Size(162, 22)
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank4.Tag = "79348"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank4.Text = "Barbarian Rank 4"
        '
        'mnuModifiersPerksCombatTwohandedBarbarianRank5
        '
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank5.Name = "mnuModifiersPerksCombatTwohandedBarbarianRank5"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank5.Size = New System.Drawing.Size(162, 22)
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank5.Tag = "79349"
        Me.mnuModifiersPerksCombatTwohandedBarbarianRank5.Text = "Barbarian Rank 5"
        '
        'mnuModifiersPerksCombatTwohandedChampionstance
        '
        Me.mnuModifiersPerksCombatTwohandedChampionstance.Name = "mnuModifiersPerksCombatTwohandedChampionstance"
        Me.mnuModifiersPerksCombatTwohandedChampionstance.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedChampionstance.Tag = "52d51"
        Me.mnuModifiersPerksCombatTwohandedChampionstance.Text = "Champion's Stance"
        '
        'mnuModifiersPerksCombatTwohandedDevastatingblow
        '
        Me.mnuModifiersPerksCombatTwohandedDevastatingblow.Name = "mnuModifiersPerksCombatTwohandedDevastatingblow"
        Me.mnuModifiersPerksCombatTwohandedDevastatingblow.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedDevastatingblow.Tag = "52d52"
        Me.mnuModifiersPerksCombatTwohandedDevastatingblow.Text = "Devastating Blow"
        '
        'mnuModifiersPerksCombatTwohandedGreatcritcharge
        '
        Me.mnuModifiersPerksCombatTwohandedGreatcritcharge.Name = "mnuModifiersPerksCombatTwohandedGreatcritcharge"
        Me.mnuModifiersPerksCombatTwohandedGreatcritcharge.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedGreatcritcharge.Tag = "cb407"
        Me.mnuModifiersPerksCombatTwohandedGreatcritcharge.Text = "Great Critical Charge"
        '
        'mnuModifiersPerksCombatTwohandedSweep
        '
        Me.mnuModifiersPerksCombatTwohandedSweep.Name = "mnuModifiersPerksCombatTwohandedSweep"
        Me.mnuModifiersPerksCombatTwohandedSweep.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedSweep.Tag = "3af9e"
        Me.mnuModifiersPerksCombatTwohandedSweep.Text = "Sweep"
        '
        'mnuModifiersPerksCombatTwohandedWarmaster
        '
        Me.mnuModifiersPerksCombatTwohandedWarmaster.Name = "mnuModifiersPerksCombatTwohandedWarmaster"
        Me.mnuModifiersPerksCombatTwohandedWarmaster.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedWarmaster.Tag = "3afa7"
        Me.mnuModifiersPerksCombatTwohandedWarmaster.Text = "Warmaster"
        '
        'mnuModifiersPerksCombatTwohandedDeepwounds
        '
        Me.mnuModifiersPerksCombatTwohandedDeepwounds.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank1, Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank2, Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank3})
        Me.mnuModifiersPerksCombatTwohandedDeepwounds.Name = "mnuModifiersPerksCombatTwohandedDeepwounds"
        Me.mnuModifiersPerksCombatTwohandedDeepwounds.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedDeepwounds.Text = "Deep Wounds"
        '
        'mnuModifiersPerksCombatTwohandedDeepwoundsRank1
        '
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank1.Name = "mnuModifiersPerksCombatTwohandedDeepwoundsRank1"
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank1.Size = New System.Drawing.Size(186, 22)
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank1.Tag = "3af83"
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank1.Text = "Deep Wounds Rank 1"
        '
        'mnuModifiersPerksCombatTwohandedDeepwoundsRank2
        '
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank2.Name = "mnuModifiersPerksCombatTwohandedDeepwoundsRank2"
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank2.Size = New System.Drawing.Size(186, 22)
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank2.Tag = "c1e94"
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank2.Text = "Deep Wounds Rank 2"
        '
        'mnuModifiersPerksCombatTwohandedDeepwoundsRank3
        '
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank3.Name = "mnuModifiersPerksCombatTwohandedDeepwoundsRank3"
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank3.Size = New System.Drawing.Size(186, 22)
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank3.Tag = "c1e95"
        Me.mnuModifiersPerksCombatTwohandedDeepwoundsRank3.Text = "Deep Wounds Rank 3"
        '
        'mnuModifiersPerksCombatTwohandedLimbsplitter
        '
        Me.mnuModifiersPerksCombatTwohandedLimbsplitter.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank1, Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank2, Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank3})
        Me.mnuModifiersPerksCombatTwohandedLimbsplitter.Name = "mnuModifiersPerksCombatTwohandedLimbsplitter"
        Me.mnuModifiersPerksCombatTwohandedLimbsplitter.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedLimbsplitter.Text = "Limbsplitter"
        '
        'mnuModifiersPerksCombatTwohandedLimbsplitterRank1
        '
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank1.Name = "mnuModifiersPerksCombatTwohandedLimbsplitterRank1"
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank1.Size = New System.Drawing.Size(175, 22)
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank1.Tag = "c5c05"
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank1.Text = "Limbsplitter Rank 1"
        '
        'mnuModifiersPerksCombatTwohandedLimbsplitterRank2
        '
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank2.Name = "mnuModifiersPerksCombatTwohandedLimbsplitterRank2"
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank2.Size = New System.Drawing.Size(175, 22)
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank2.Tag = "c5c06"
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank2.Text = "Limbsplitter Rank 2"
        '
        'mnuModifiersPerksCombatTwohandedLimbsplitterRank3
        '
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank3.Name = "mnuModifiersPerksCombatTwohandedLimbsplitterRank3"
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank3.Size = New System.Drawing.Size(175, 22)
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank3.Tag = "c5c07"
        Me.mnuModifiersPerksCombatTwohandedLimbsplitterRank3.Text = "Limbsplitter Rank 3"
        '
        'mnuModifiersPerksCombatTwohandedSkullcrusher
        '
        Me.mnuModifiersPerksCombatTwohandedSkullcrusher.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank1, Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank2, Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank3})
        Me.mnuModifiersPerksCombatTwohandedSkullcrusher.Name = "mnuModifiersPerksCombatTwohandedSkullcrusher"
        Me.mnuModifiersPerksCombatTwohandedSkullcrusher.Size = New System.Drawing.Size(183, 22)
        Me.mnuModifiersPerksCombatTwohandedSkullcrusher.Text = "Skullcrusher"
        '
        'mnuModifiersPerksCombatTwohandedSkullcrusherRank1
        '
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank1.Name = "mnuModifiersPerksCombatTwohandedSkullcrusherRank1"
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank1.Size = New System.Drawing.Size(176, 22)
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank1.Tag = "3af84"
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank1.Text = "Skullcrusher Rank 1"
        '
        'mnuModifiersPerksCombatTwohandedSkullcrusherRank2
        '
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank2.Name = "mnuModifiersPerksCombatTwohandedSkullcrusherRank2"
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank2.Size = New System.Drawing.Size(176, 22)
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank2.Tag = "c1e96"
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank2.Text = "Skullcrusher Rank 2"
        '
        'mnuModifiersPerksCombatTwohandedSkullcrusherRank3
        '
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank3.Name = "mnuModifiersPerksCombatTwohandedSkullcrusherRank3"
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank3.Size = New System.Drawing.Size(176, 22)
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank3.Tag = "c1e97"
        Me.mnuModifiersPerksCombatTwohandedSkullcrusherRank3.Text = "Skullcrusher Rank 3"
        '
        'mnuModsPerksStealth
        '
        Me.mnuModsPerksStealth.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthAlchemy, Me.mnuModifiersPerksStealthLightarmor, Me.mnuModifiersPerksStealthLockpicking, Me.mnuModifiersPerksStealthPickpocket, Me.mnuModifiersPerksStealthSneak, Me.mnuModifiersPerksStealthSpeech})
        Me.mnuModsPerksStealth.Name = "mnuModsPerksStealth"
        Me.mnuModsPerksStealth.Size = New System.Drawing.Size(196, 22)
        Me.mnuModsPerksStealth.Text = "Stealth"
        '
        'mnuModifiersPerksStealthAlchemy
        '
        Me.mnuModifiersPerksStealthAlchemy.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthAlchemyAlchemist, Me.mnuModifiersPerksStealthAlchemyPhysician, Me.mnuModifiersPerksStealthAlchemyBenefactor, Me.mnuModifiersPerksStealthAlchemyExperimenter, Me.mnuModifiersPerksStealthAlchemyPoisoner, Me.mnuModifiersPerksStealthAlchemyConcpoison, Me.mnuModifiersPerksStealthAlchemyGreenthumb, Me.mnuModifiersPerksStealthAlchemySnakeblood, Me.mnuModifiersPerksStealthAlchemyPurity})
        Me.mnuModifiersPerksStealthAlchemy.Name = "mnuModifiersPerksStealthAlchemy"
        Me.mnuModifiersPerksStealthAlchemy.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksStealthAlchemy.Text = "Alchemy"
        '
        'mnuModifiersPerksStealthAlchemyAlchemist
        '
        Me.mnuModifiersPerksStealthAlchemyAlchemist.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthAlchemyAlchemistRank1, Me.mnuModifiersPerksStealthAlchemyAlchemistRank2, Me.mnuModifiersPerksStealthAlchemyAlchemistRank3, Me.mnuModifiersPerksStealthAlchemyAlchemistRank4, Me.mnuModifiersPerksStealthAlchemyAlchemistRank5})
        Me.mnuModifiersPerksStealthAlchemyAlchemist.Name = "mnuModifiersPerksStealthAlchemyAlchemist"
        Me.mnuModifiersPerksStealthAlchemyAlchemist.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemyAlchemist.Text = "Alchemist"
        '
        'mnuModifiersPerksStealthAlchemyAlchemistRank1
        '
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank1.Name = "mnuModifiersPerksStealthAlchemyAlchemistRank1"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank1.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank1.Tag = "be127"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank1.Text = "Alchemist Rank 1"
        '
        'mnuModifiersPerksStealthAlchemyAlchemistRank2
        '
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank2.Name = "mnuModifiersPerksStealthAlchemyAlchemistRank2"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank2.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank2.Tag = "c07ca"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank2.Text = "Alchemist Rank 2"
        '
        'mnuModifiersPerksStealthAlchemyAlchemistRank3
        '
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank3.Name = "mnuModifiersPerksStealthAlchemyAlchemistRank3"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank3.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank3.Tag = "c07cb"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank3.Text = "Alchemist Rank 3"
        '
        'mnuModifiersPerksStealthAlchemyAlchemistRank4
        '
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank4.Name = "mnuModifiersPerksStealthAlchemyAlchemistRank4"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank4.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank4.Tag = "c07cc"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank4.Text = "Alchemist Rank 4"
        '
        'mnuModifiersPerksStealthAlchemyAlchemistRank5
        '
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank5.Name = "mnuModifiersPerksStealthAlchemyAlchemistRank5"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank5.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank5.Tag = "c07cd"
        Me.mnuModifiersPerksStealthAlchemyAlchemistRank5.Text = "Alchemist Rank 5"
        '
        'mnuModifiersPerksStealthAlchemyPhysician
        '
        Me.mnuModifiersPerksStealthAlchemyPhysician.Name = "mnuModifiersPerksStealthAlchemyPhysician"
        Me.mnuModifiersPerksStealthAlchemyPhysician.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemyPhysician.Tag = "58215"
        Me.mnuModifiersPerksStealthAlchemyPhysician.Text = "Physician"
        '
        'mnuModifiersPerksStealthAlchemyBenefactor
        '
        Me.mnuModifiersPerksStealthAlchemyBenefactor.Name = "mnuModifiersPerksStealthAlchemyBenefactor"
        Me.mnuModifiersPerksStealthAlchemyBenefactor.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemyBenefactor.Tag = "58216"
        Me.mnuModifiersPerksStealthAlchemyBenefactor.Text = "Benefactor"
        '
        'mnuModifiersPerksStealthAlchemyExperimenter
        '
        Me.mnuModifiersPerksStealthAlchemyExperimenter.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthAlchemyExperimenterRank1, Me.mnuModifiersPerksStealthAlchemyExperimenterRank2, Me.mnuModifiersPerksStealthAlchemyExperimenterRank3})
        Me.mnuModifiersPerksStealthAlchemyExperimenter.Name = "mnuModifiersPerksStealthAlchemyExperimenter"
        Me.mnuModifiersPerksStealthAlchemyExperimenter.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemyExperimenter.Text = "Experimenter"
        '
        'mnuModifiersPerksStealthAlchemyExperimenterRank1
        '
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank1.Name = "mnuModifiersPerksStealthAlchemyExperimenterRank1"
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank1.Size = New System.Drawing.Size(181, 22)
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank1.Tag = "58218"
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank1.Text = "Experimenter Rank 1"
        '
        'mnuModifiersPerksStealthAlchemyExperimenterRank2
        '
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank2.Name = "mnuModifiersPerksStealthAlchemyExperimenterRank2"
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank2.Size = New System.Drawing.Size(181, 22)
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank2.Tag = "105f2a"
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank2.Text = "Experimenter Rank 2"
        '
        'mnuModifiersPerksStealthAlchemyExperimenterRank3
        '
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank3.Name = "mnuModifiersPerksStealthAlchemyExperimenterRank3"
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank3.Size = New System.Drawing.Size(181, 22)
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank3.Tag = "105f2b"
        Me.mnuModifiersPerksStealthAlchemyExperimenterRank3.Text = "Experimenter Rank 3"
        '
        'mnuModifiersPerksStealthAlchemyPoisoner
        '
        Me.mnuModifiersPerksStealthAlchemyPoisoner.Name = "mnuModifiersPerksStealthAlchemyPoisoner"
        Me.mnuModifiersPerksStealthAlchemyPoisoner.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemyPoisoner.Tag = "58217"
        Me.mnuModifiersPerksStealthAlchemyPoisoner.Text = "Poisoner"
        '
        'mnuModifiersPerksStealthAlchemyConcpoison
        '
        Me.mnuModifiersPerksStealthAlchemyConcpoison.Name = "mnuModifiersPerksStealthAlchemyConcpoison"
        Me.mnuModifiersPerksStealthAlchemyConcpoison.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemyConcpoison.Tag = "105f2f"
        Me.mnuModifiersPerksStealthAlchemyConcpoison.Text = "Concentrated Poison"
        '
        'mnuModifiersPerksStealthAlchemyGreenthumb
        '
        Me.mnuModifiersPerksStealthAlchemyGreenthumb.Name = "mnuModifiersPerksStealthAlchemyGreenthumb"
        Me.mnuModifiersPerksStealthAlchemyGreenthumb.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemyGreenthumb.Tag = "105f2e"
        Me.mnuModifiersPerksStealthAlchemyGreenthumb.Text = "Green Thumb"
        '
        'mnuModifiersPerksStealthAlchemySnakeblood
        '
        Me.mnuModifiersPerksStealthAlchemySnakeblood.Name = "mnuModifiersPerksStealthAlchemySnakeblood"
        Me.mnuModifiersPerksStealthAlchemySnakeblood.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemySnakeblood.Tag = "105f2c"
        Me.mnuModifiersPerksStealthAlchemySnakeblood.Text = "Snakeblood"
        '
        'mnuModifiersPerksStealthAlchemyPurity
        '
        Me.mnuModifiersPerksStealthAlchemyPurity.Name = "mnuModifiersPerksStealthAlchemyPurity"
        Me.mnuModifiersPerksStealthAlchemyPurity.Size = New System.Drawing.Size(185, 22)
        Me.mnuModifiersPerksStealthAlchemyPurity.Tag = "5821d"
        Me.mnuModifiersPerksStealthAlchemyPurity.Text = "Purity"
        '
        'mnuModifiersPerksStealthLightarmor
        '
        Me.mnuModifiersPerksStealthLightarmor.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthLightarmorAgiledefender, Me.mnuModifiersPerksStealthLightarmorCustomfit, Me.mnuModifiersPerksStealthLightarmorMatchset, Me.mnuModifiersPerksStealthLightarmorUnhindered, Me.mnuModifiersPerksStealthLightarmorWind, Me.mnuModifiersPerksStealthLightarmorDeftmove})
        Me.mnuModifiersPerksStealthLightarmor.Name = "mnuModifiersPerksStealthLightarmor"
        Me.mnuModifiersPerksStealthLightarmor.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksStealthLightarmor.Text = "Light Armor"
        '
        'mnuModifiersPerksStealthLightarmorAgiledefender
        '
        Me.mnuModifiersPerksStealthLightarmorAgiledefender.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank1, Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank2, Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank3, Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank4, Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank5})
        Me.mnuModifiersPerksStealthLightarmorAgiledefender.Name = "mnuModifiersPerksStealthLightarmorAgiledefender"
        Me.mnuModifiersPerksStealthLightarmorAgiledefender.Size = New System.Drawing.Size(157, 22)
        Me.mnuModifiersPerksStealthLightarmorAgiledefender.Text = "Agile Defender"
        '
        'mnuModifiersPerksStealthLightarmorAgiledefenderRank1
        '
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank1.Name = "mnuModifiersPerksStealthLightarmorAgiledefenderRank1"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank1.Size = New System.Drawing.Size(190, 22)
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank1.Tag = "be123"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank1.Text = "Agile Defender Rank 1"
        '
        'mnuModifiersPerksStealthLightarmorAgiledefenderRank2
        '
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank2.Name = "mnuModifiersPerksStealthLightarmorAgiledefenderRank2"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank2.Size = New System.Drawing.Size(190, 22)
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank2.Tag = "79376"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank2.Text = "Agile Defender Rank 2"
        '
        'mnuModifiersPerksStealthLightarmorAgiledefenderRank3
        '
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank3.Name = "mnuModifiersPerksStealthLightarmorAgiledefenderRank3"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank3.Size = New System.Drawing.Size(190, 22)
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank3.Tag = "79389"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank3.Text = "Agile Defender Rank 3"
        '
        'mnuModifiersPerksStealthLightarmorAgiledefenderRank4
        '
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank4.Name = "mnuModifiersPerksStealthLightarmorAgiledefenderRank4"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank4.Size = New System.Drawing.Size(190, 22)
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank4.Tag = "79391"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank4.Text = "Agile Defender Rank 4"
        '
        'mnuModifiersPerksStealthLightarmorAgiledefenderRank5
        '
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank5.Name = "mnuModifiersPerksStealthLightarmorAgiledefenderRank5"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank5.Size = New System.Drawing.Size(190, 22)
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank5.Tag = "79392"
        Me.mnuModifiersPerksStealthLightarmorAgiledefenderRank5.Text = "Agile Defender Rank 5"
        '
        'mnuModifiersPerksStealthLightarmorCustomfit
        '
        Me.mnuModifiersPerksStealthLightarmorCustomfit.Name = "mnuModifiersPerksStealthLightarmorCustomfit"
        Me.mnuModifiersPerksStealthLightarmorCustomfit.Size = New System.Drawing.Size(157, 22)
        Me.mnuModifiersPerksStealthLightarmorCustomfit.Tag = "51b1b"
        Me.mnuModifiersPerksStealthLightarmorCustomfit.Text = "Custom Fit"
        '
        'mnuModifiersPerksStealthLightarmorMatchset
        '
        Me.mnuModifiersPerksStealthLightarmorMatchset.Name = "mnuModifiersPerksStealthLightarmorMatchset"
        Me.mnuModifiersPerksStealthLightarmorMatchset.Size = New System.Drawing.Size(157, 22)
        Me.mnuModifiersPerksStealthLightarmorMatchset.Tag = "51b17"
        Me.mnuModifiersPerksStealthLightarmorMatchset.Text = "Matching Set"
        '
        'mnuModifiersPerksStealthLightarmorUnhindered
        '
        Me.mnuModifiersPerksStealthLightarmorUnhindered.Name = "mnuModifiersPerksStealthLightarmorUnhindered"
        Me.mnuModifiersPerksStealthLightarmorUnhindered.Size = New System.Drawing.Size(157, 22)
        Me.mnuModifiersPerksStealthLightarmorUnhindered.Tag = "51b1c"
        Me.mnuModifiersPerksStealthLightarmorUnhindered.Text = "Unhindered"
        '
        'mnuModifiersPerksStealthLightarmorWind
        '
        Me.mnuModifiersPerksStealthLightarmorWind.Name = "mnuModifiersPerksStealthLightarmorWind"
        Me.mnuModifiersPerksStealthLightarmorWind.Size = New System.Drawing.Size(157, 22)
        Me.mnuModifiersPerksStealthLightarmorWind.Tag = "105f22"
        Me.mnuModifiersPerksStealthLightarmorWind.Text = "Wind Walker"
        '
        'mnuModifiersPerksStealthLightarmorDeftmove
        '
        Me.mnuModifiersPerksStealthLightarmorDeftmove.Name = "mnuModifiersPerksStealthLightarmorDeftmove"
        Me.mnuModifiersPerksStealthLightarmorDeftmove.Size = New System.Drawing.Size(157, 22)
        Me.mnuModifiersPerksStealthLightarmorDeftmove.Tag = "107831"
        Me.mnuModifiersPerksStealthLightarmorDeftmove.Text = "Deft Movement"
        '
        'mnuModifiersPerksStealthLockpicking
        '
        Me.mnuModifiersPerksStealthLockpicking.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthLockpickingNovice, Me.mnuModifiersPerksStealthLockpickingApprentice, Me.mnuModifiersPerksStealthLockpickingQuickhands, Me.mnuModifiersPerksStealthLockpickingWaxkey, Me.mnuModifiersPerksStealthLockpickingAdept, Me.mnuModifiersPerksStealthLockpickingExpert, Me.mnuModifiersPerksStealthLockpickingGoldtouch, Me.mnuModifiersPerksStealthLockpickingTreasure, Me.mnuModifiersPerksStealthLockpickingLocksmith, Me.mnuModifiersPerksStealthLockpickingUnbreakable, Me.mnuModifiersPerksStealthLockpickingMaster})
        Me.mnuModifiersPerksStealthLockpicking.Name = "mnuModifiersPerksStealthLockpicking"
        Me.mnuModifiersPerksStealthLockpicking.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksStealthLockpicking.Text = "Lockpicking"
        '
        'mnuModifiersPerksStealthLockpickingNovice
        '
        Me.mnuModifiersPerksStealthLockpickingNovice.Name = "mnuModifiersPerksStealthLockpickingNovice"
        Me.mnuModifiersPerksStealthLockpickingNovice.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingNovice.Tag = "f392a"
        Me.mnuModifiersPerksStealthLockpickingNovice.Text = "Novice Locks"
        '
        'mnuModifiersPerksStealthLockpickingApprentice
        '
        Me.mnuModifiersPerksStealthLockpickingApprentice.Name = "mnuModifiersPerksStealthLockpickingApprentice"
        Me.mnuModifiersPerksStealthLockpickingApprentice.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingApprentice.Tag = "be125"
        Me.mnuModifiersPerksStealthLockpickingApprentice.Text = "Apprentice Locks"
        '
        'mnuModifiersPerksStealthLockpickingQuickhands
        '
        Me.mnuModifiersPerksStealthLockpickingQuickhands.Name = "mnuModifiersPerksStealthLockpickingQuickhands"
        Me.mnuModifiersPerksStealthLockpickingQuickhands.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingQuickhands.Tag = "106259"
        Me.mnuModifiersPerksStealthLockpickingQuickhands.Text = "Quick Hands"
        '
        'mnuModifiersPerksStealthLockpickingWaxkey
        '
        Me.mnuModifiersPerksStealthLockpickingWaxkey.Name = "mnuModifiersPerksStealthLockpickingWaxkey"
        Me.mnuModifiersPerksStealthLockpickingWaxkey.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingWaxkey.Tag = "107830"
        Me.mnuModifiersPerksStealthLockpickingWaxkey.Text = "Wax Key"
        '
        'mnuModifiersPerksStealthLockpickingAdept
        '
        Me.mnuModifiersPerksStealthLockpickingAdept.Name = "mnuModifiersPerksStealthLockpickingAdept"
        Me.mnuModifiersPerksStealthLockpickingAdept.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingAdept.Tag = "c3680"
        Me.mnuModifiersPerksStealthLockpickingAdept.Text = "Adept Locks"
        '
        'mnuModifiersPerksStealthLockpickingExpert
        '
        Me.mnuModifiersPerksStealthLockpickingExpert.Name = "mnuModifiersPerksStealthLockpickingExpert"
        Me.mnuModifiersPerksStealthLockpickingExpert.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingExpert.Tag = "c3681"
        Me.mnuModifiersPerksStealthLockpickingExpert.Text = "Expert Locks"
        '
        'mnuModifiersPerksStealthLockpickingGoldtouch
        '
        Me.mnuModifiersPerksStealthLockpickingGoldtouch.Name = "mnuModifiersPerksStealthLockpickingGoldtouch"
        Me.mnuModifiersPerksStealthLockpickingGoldtouch.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingGoldtouch.Tag = "5820a"
        Me.mnuModifiersPerksStealthLockpickingGoldtouch.Text = "Golden Touch"
        '
        'mnuModifiersPerksStealthLockpickingTreasure
        '
        Me.mnuModifiersPerksStealthLockpickingTreasure.Name = "mnuModifiersPerksStealthLockpickingTreasure"
        Me.mnuModifiersPerksStealthLockpickingTreasure.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingTreasure.Tag = "105f26"
        Me.mnuModifiersPerksStealthLockpickingTreasure.Text = "Treasure Hunter"
        '
        'mnuModifiersPerksStealthLockpickingLocksmith
        '
        Me.mnuModifiersPerksStealthLockpickingLocksmith.Name = "mnuModifiersPerksStealthLockpickingLocksmith"
        Me.mnuModifiersPerksStealthLockpickingLocksmith.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingLocksmith.Tag = "58208"
        Me.mnuModifiersPerksStealthLockpickingLocksmith.Text = "Locksmith"
        '
        'mnuModifiersPerksStealthLockpickingUnbreakable
        '
        Me.mnuModifiersPerksStealthLockpickingUnbreakable.Name = "mnuModifiersPerksStealthLockpickingUnbreakable"
        Me.mnuModifiersPerksStealthLockpickingUnbreakable.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingUnbreakable.Tag = "58209"
        Me.mnuModifiersPerksStealthLockpickingUnbreakable.Text = "Unbreakable"
        '
        'mnuModifiersPerksStealthLockpickingMaster
        '
        Me.mnuModifiersPerksStealthLockpickingMaster.Name = "mnuModifiersPerksStealthLockpickingMaster"
        Me.mnuModifiersPerksStealthLockpickingMaster.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksStealthLockpickingMaster.Tag = "c3682"
        Me.mnuModifiersPerksStealthLockpickingMaster.Text = "Master Locks"
        '
        'mnuModifiersPerksStealthPickpocket
        '
        Me.mnuModifiersPerksStealthPickpocket.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthPickpocketLightfingers, Me.mnuModifiersPerksStealthPickpocketNight, Me.mnuModifiersPerksStealthPickpocketCutpurse, Me.mnuModifiersPerksStealthPickpocketKeymaster, Me.mnuModifiersPerksStealthPickpocketMisdirection, Me.mnuModifiersPerksStealthPickpocketPerfecttouch, Me.mnuModifiersPerksStealthPickpocketExtrapockets, Me.mnuModifiersPerksStealthPickpocketPoisoned})
        Me.mnuModifiersPerksStealthPickpocket.Name = "mnuModifiersPerksStealthPickpocket"
        Me.mnuModifiersPerksStealthPickpocket.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksStealthPickpocket.Text = "Pickpocket"
        '
        'mnuModifiersPerksStealthPickpocketLightfingers
        '
        Me.mnuModifiersPerksStealthPickpocketLightfingers.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthPickpocketLightfingersRank1, Me.mnuModifiersPerksStealthPickpocketLightfingersRank2, Me.mnuModifiersPerksStealthPickpocketLightfingersRank3, Me.mnuModifiersPerksStealthPickpocketLightfingersRank4, Me.mnuModifiersPerksStealthPickpocketLightfingersRank5})
        Me.mnuModifiersPerksStealthPickpocketLightfingers.Name = "mnuModifiersPerksStealthPickpocketLightfingers"
        Me.mnuModifiersPerksStealthPickpocketLightfingers.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthPickpocketLightfingers.Text = "Light Fingers"
        '
        'mnuModifiersPerksStealthPickpocketLightfingersRank1
        '
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank1.Name = "mnuModifiersPerksStealthPickpocketLightfingersRank1"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank1.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank1.Tag = "be124"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank1.Text = "Light Fingers Rank 1"
        '
        'mnuModifiersPerksStealthPickpocketLightfingersRank2
        '
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank2.Name = "mnuModifiersPerksStealthPickpocketLightfingersRank2"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank2.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank2.Tag = "18e6a"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank2.Text = "Light Fingers Rank 2"
        '
        'mnuModifiersPerksStealthPickpocketLightfingersRank3
        '
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank3.Name = "mnuModifiersPerksStealthPickpocketLightfingersRank3"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank3.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank3.Tag = "18e6b"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank3.Text = "Light Fingers Rank 3"
        '
        'mnuModifiersPerksStealthPickpocketLightfingersRank4
        '
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank4.Name = "mnuModifiersPerksStealthPickpocketLightfingersRank4"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank4.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank4.Tag = "18e6c"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank4.Text = "Light Fingers Rank 4"
        '
        'mnuModifiersPerksStealthPickpocketLightfingersRank5
        '
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank5.Name = "mnuModifiersPerksStealthPickpocketLightfingersRank5"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank5.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank5.Tag = "18e6d"
        Me.mnuModifiersPerksStealthPickpocketLightfingersRank5.Text = "Light Fingers Rank 5"
        '
        'mnuModifiersPerksStealthPickpocketNight
        '
        Me.mnuModifiersPerksStealthPickpocketNight.Name = "mnuModifiersPerksStealthPickpocketNight"
        Me.mnuModifiersPerksStealthPickpocketNight.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthPickpocketNight.Tag = "58202"
        Me.mnuModifiersPerksStealthPickpocketNight.Text = "Night Thief"
        '
        'mnuModifiersPerksStealthPickpocketCutpurse
        '
        Me.mnuModifiersPerksStealthPickpocketCutpurse.Name = "mnuModifiersPerksStealthPickpocketCutpurse"
        Me.mnuModifiersPerksStealthPickpocketCutpurse.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthPickpocketCutpurse.Tag = "58204"
        Me.mnuModifiersPerksStealthPickpocketCutpurse.Text = "Cutpurse"
        '
        'mnuModifiersPerksStealthPickpocketKeymaster
        '
        Me.mnuModifiersPerksStealthPickpocketKeymaster.Name = "mnuModifiersPerksStealthPickpocketKeymaster"
        Me.mnuModifiersPerksStealthPickpocketKeymaster.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthPickpocketKeymaster.Tag = "d79a0"
        Me.mnuModifiersPerksStealthPickpocketKeymaster.Text = "Keymaster"
        '
        'mnuModifiersPerksStealthPickpocketMisdirection
        '
        Me.mnuModifiersPerksStealthPickpocketMisdirection.Name = "mnuModifiersPerksStealthPickpocketMisdirection"
        Me.mnuModifiersPerksStealthPickpocketMisdirection.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthPickpocketMisdirection.Tag = "58201"
        Me.mnuModifiersPerksStealthPickpocketMisdirection.Text = "Misdirection"
        '
        'mnuModifiersPerksStealthPickpocketPerfecttouch
        '
        Me.mnuModifiersPerksStealthPickpocketPerfecttouch.Name = "mnuModifiersPerksStealthPickpocketPerfecttouch"
        Me.mnuModifiersPerksStealthPickpocketPerfecttouch.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthPickpocketPerfecttouch.Tag = "58205"
        Me.mnuModifiersPerksStealthPickpocketPerfecttouch.Text = "Perfect Touch"
        '
        'mnuModifiersPerksStealthPickpocketExtrapockets
        '
        Me.mnuModifiersPerksStealthPickpocketExtrapockets.Name = "mnuModifiersPerksStealthPickpocketExtrapockets"
        Me.mnuModifiersPerksStealthPickpocketExtrapockets.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthPickpocketExtrapockets.Tag = "96590"
        Me.mnuModifiersPerksStealthPickpocketExtrapockets.Text = "Extra Pockets"
        '
        'mnuModifiersPerksStealthPickpocketPoisoned
        '
        Me.mnuModifiersPerksStealthPickpocketPoisoned.Name = "mnuModifiersPerksStealthPickpocketPoisoned"
        Me.mnuModifiersPerksStealthPickpocketPoisoned.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthPickpocketPoisoned.Tag = "105f28"
        Me.mnuModifiersPerksStealthPickpocketPoisoned.Text = "Poisoned"
        '
        'mnuModifiersPerksStealthSneak
        '
        Me.mnuModifiersPerksStealthSneak.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthSneakStealth, Me.mnuModifiersPerksStealthSneakBackstab, Me.mnuModifiersPerksStealthSneakDeadlyaim, Me.mnuModifiersPerksStealthSneakAssblade, Me.mnuModifiersPerksStealthSneakMufflemove, Me.mnuModifiersPerksStealthSneakLightfoot, Me.mnuModifiersPerksStealthSneakSilentroll, Me.mnuModifiersPerksStealthSneakSilence, Me.mnuModifiersPerksStealthSneakShadow})
        Me.mnuModifiersPerksStealthSneak.Name = "mnuModifiersPerksStealthSneak"
        Me.mnuModifiersPerksStealthSneak.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksStealthSneak.Text = "Sneak"
        '
        'mnuModifiersPerksStealthSneakStealth
        '
        Me.mnuModifiersPerksStealthSneakStealth.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthSneakStealthRank1, Me.mnuModifiersPerksStealthSneakStealthRank2, Me.mnuModifiersPerksStealthSneakStealthRank3, Me.mnuModifiersPerksStealthSneakStealthRank4, Me.mnuModifiersPerksStealthSneakStealthRank5})
        Me.mnuModifiersPerksStealthSneakStealth.Name = "mnuModifiersPerksStealthSneakStealth"
        Me.mnuModifiersPerksStealthSneakStealth.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakStealth.Text = "Stealth"
        '
        'mnuModifiersPerksStealthSneakStealthRank1
        '
        Me.mnuModifiersPerksStealthSneakStealthRank1.Name = "mnuModifiersPerksStealthSneakStealthRank1"
        Me.mnuModifiersPerksStealthSneakStealthRank1.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthSneakStealthRank1.Tag = "be126"
        Me.mnuModifiersPerksStealthSneakStealthRank1.Text = "Stealth Rank 1"
        '
        'mnuModifiersPerksStealthSneakStealthRank2
        '
        Me.mnuModifiersPerksStealthSneakStealthRank2.Name = "mnuModifiersPerksStealthSneakStealthRank2"
        Me.mnuModifiersPerksStealthSneakStealthRank2.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthSneakStealthRank2.Tag = "c07c6"
        Me.mnuModifiersPerksStealthSneakStealthRank2.Text = "Stealth Rank 2"
        '
        'mnuModifiersPerksStealthSneakStealthRank3
        '
        Me.mnuModifiersPerksStealthSneakStealthRank3.Name = "mnuModifiersPerksStealthSneakStealthRank3"
        Me.mnuModifiersPerksStealthSneakStealthRank3.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthSneakStealthRank3.Tag = "c07c7"
        Me.mnuModifiersPerksStealthSneakStealthRank3.Text = "Stealth Rank 3"
        '
        'mnuModifiersPerksStealthSneakStealthRank4
        '
        Me.mnuModifiersPerksStealthSneakStealthRank4.Name = "mnuModifiersPerksStealthSneakStealthRank4"
        Me.mnuModifiersPerksStealthSneakStealthRank4.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthSneakStealthRank4.Tag = "c07c8"
        Me.mnuModifiersPerksStealthSneakStealthRank4.Text = "Stealth Rank 4"
        '
        'mnuModifiersPerksStealthSneakStealthRank5
        '
        Me.mnuModifiersPerksStealthSneakStealthRank5.Name = "mnuModifiersPerksStealthSneakStealthRank5"
        Me.mnuModifiersPerksStealthSneakStealthRank5.Size = New System.Drawing.Size(148, 22)
        Me.mnuModifiersPerksStealthSneakStealthRank5.Tag = "c07c9"
        Me.mnuModifiersPerksStealthSneakStealthRank5.Text = "Stealth Rank 5"
        '
        'mnuModifiersPerksStealthSneakBackstab
        '
        Me.mnuModifiersPerksStealthSneakBackstab.Name = "mnuModifiersPerksStealthSneakBackstab"
        Me.mnuModifiersPerksStealthSneakBackstab.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakBackstab.Tag = "58210"
        Me.mnuModifiersPerksStealthSneakBackstab.Text = "Backstab"
        '
        'mnuModifiersPerksStealthSneakDeadlyaim
        '
        Me.mnuModifiersPerksStealthSneakDeadlyaim.Name = "mnuModifiersPerksStealthSneakDeadlyaim"
        Me.mnuModifiersPerksStealthSneakDeadlyaim.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakDeadlyaim.Tag = "1036f0"
        Me.mnuModifiersPerksStealthSneakDeadlyaim.Text = "Deadly Aim"
        '
        'mnuModifiersPerksStealthSneakAssblade
        '
        Me.mnuModifiersPerksStealthSneakAssblade.Name = "mnuModifiersPerksStealthSneakAssblade"
        Me.mnuModifiersPerksStealthSneakAssblade.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakAssblade.Tag = "58211"
        Me.mnuModifiersPerksStealthSneakAssblade.Text = "Assassin's Blade"
        '
        'mnuModifiersPerksStealthSneakMufflemove
        '
        Me.mnuModifiersPerksStealthSneakMufflemove.Name = "mnuModifiersPerksStealthSneakMufflemove"
        Me.mnuModifiersPerksStealthSneakMufflemove.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakMufflemove.Tag = "58213"
        Me.mnuModifiersPerksStealthSneakMufflemove.Text = "Muffled Movement"
        '
        'mnuModifiersPerksStealthSneakLightfoot
        '
        Me.mnuModifiersPerksStealthSneakLightfoot.Name = "mnuModifiersPerksStealthSneakLightfoot"
        Me.mnuModifiersPerksStealthSneakLightfoot.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakLightfoot.Tag = "5820c"
        Me.mnuModifiersPerksStealthSneakLightfoot.Text = "Light Foot"
        '
        'mnuModifiersPerksStealthSneakSilentroll
        '
        Me.mnuModifiersPerksStealthSneakSilentroll.Name = "mnuModifiersPerksStealthSneakSilentroll"
        Me.mnuModifiersPerksStealthSneakSilentroll.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakSilentroll.Tag = "105f23"
        Me.mnuModifiersPerksStealthSneakSilentroll.Text = "Silent Roll"
        '
        'mnuModifiersPerksStealthSneakSilence
        '
        Me.mnuModifiersPerksStealthSneakSilence.Name = "mnuModifiersPerksStealthSneakSilence"
        Me.mnuModifiersPerksStealthSneakSilence.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakSilence.Tag = "105f24"
        Me.mnuModifiersPerksStealthSneakSilence.Text = "Silence"
        '
        'mnuModifiersPerksStealthSneakShadow
        '
        Me.mnuModifiersPerksStealthSneakShadow.Name = "mnuModifiersPerksStealthSneakShadow"
        Me.mnuModifiersPerksStealthSneakShadow.Size = New System.Drawing.Size(177, 22)
        Me.mnuModifiersPerksStealthSneakShadow.Tag = "58214"
        Me.mnuModifiersPerksStealthSneakShadow.Text = "Shadow Warrior"
        '
        'mnuModifiersPerksStealthSpeech
        '
        Me.mnuModifiersPerksStealthSpeech.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthSpeechHaggle, Me.mnuModifiersPerksStealthSpeechAllure, Me.mnuModifiersPerksStealthSpeechMerchant, Me.mnuModifiersPerksStealthSpeechInvestor, Me.mnuModifiersPerksStealthSpeechFence, Me.mnuModifiersPerksStealthSpeechMaster, Me.mnuModifiersPerksStealthSpeechBribe, Me.mnuModifiersPerksStealthSpeechPersuasion, Me.mnuModifiersPerksStealthSpeechIntimidation})
        Me.mnuModifiersPerksStealthSpeech.Name = "mnuModifiersPerksStealthSpeech"
        Me.mnuModifiersPerksStealthSpeech.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksStealthSpeech.Text = "Speech"
        '
        'mnuModifiersPerksStealthSpeechHaggle
        '
        Me.mnuModifiersPerksStealthSpeechHaggle.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksStealthSpeechHaggleRank1, Me.mnuModifiersPerksStealthSpeechHaggleRank2, Me.mnuModifiersPerksStealthSpeechHaggleRank3, Me.mnuModifiersPerksStealthSpeechHaggleRank4, Me.mnuModifiersPerksStealthSpeechHaggleRank5})
        Me.mnuModifiersPerksStealthSpeechHaggle.Name = "mnuModifiersPerksStealthSpeechHaggle"
        Me.mnuModifiersPerksStealthSpeechHaggle.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechHaggle.Text = "Haggling"
        '
        'mnuModifiersPerksStealthSpeechHaggleRank1
        '
        Me.mnuModifiersPerksStealthSpeechHaggleRank1.Name = "mnuModifiersPerksStealthSpeechHaggleRank1"
        Me.mnuModifiersPerksStealthSpeechHaggleRank1.Size = New System.Drawing.Size(161, 22)
        Me.mnuModifiersPerksStealthSpeechHaggleRank1.Tag = "be128"
        Me.mnuModifiersPerksStealthSpeechHaggleRank1.Text = "Haggling Rank 1"
        '
        'mnuModifiersPerksStealthSpeechHaggleRank2
        '
        Me.mnuModifiersPerksStealthSpeechHaggleRank2.Name = "mnuModifiersPerksStealthSpeechHaggleRank2"
        Me.mnuModifiersPerksStealthSpeechHaggleRank2.Size = New System.Drawing.Size(161, 22)
        Me.mnuModifiersPerksStealthSpeechHaggleRank2.Tag = "c07ce"
        Me.mnuModifiersPerksStealthSpeechHaggleRank2.Text = "Haggling Rank 2"
        '
        'mnuModifiersPerksStealthSpeechHaggleRank3
        '
        Me.mnuModifiersPerksStealthSpeechHaggleRank3.Name = "mnuModifiersPerksStealthSpeechHaggleRank3"
        Me.mnuModifiersPerksStealthSpeechHaggleRank3.Size = New System.Drawing.Size(161, 22)
        Me.mnuModifiersPerksStealthSpeechHaggleRank3.Tag = "c07cf"
        Me.mnuModifiersPerksStealthSpeechHaggleRank3.Text = "Haggling Rank 3"
        '
        'mnuModifiersPerksStealthSpeechHaggleRank4
        '
        Me.mnuModifiersPerksStealthSpeechHaggleRank4.Name = "mnuModifiersPerksStealthSpeechHaggleRank4"
        Me.mnuModifiersPerksStealthSpeechHaggleRank4.Size = New System.Drawing.Size(161, 22)
        Me.mnuModifiersPerksStealthSpeechHaggleRank4.Tag = "c07d0"
        Me.mnuModifiersPerksStealthSpeechHaggleRank4.Text = "Haggling Rank 4"
        '
        'mnuModifiersPerksStealthSpeechHaggleRank5
        '
        Me.mnuModifiersPerksStealthSpeechHaggleRank5.Name = "mnuModifiersPerksStealthSpeechHaggleRank5"
        Me.mnuModifiersPerksStealthSpeechHaggleRank5.Size = New System.Drawing.Size(161, 22)
        Me.mnuModifiersPerksStealthSpeechHaggleRank5.Tag = "c07d1"
        Me.mnuModifiersPerksStealthSpeechHaggleRank5.Text = "Haggling Rank 5"
        '
        'mnuModifiersPerksStealthSpeechAllure
        '
        Me.mnuModifiersPerksStealthSpeechAllure.Name = "mnuModifiersPerksStealthSpeechAllure"
        Me.mnuModifiersPerksStealthSpeechAllure.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechAllure.Tag = "58f75"
        Me.mnuModifiersPerksStealthSpeechAllure.Text = "Allure"
        '
        'mnuModifiersPerksStealthSpeechMerchant
        '
        Me.mnuModifiersPerksStealthSpeechMerchant.Name = "mnuModifiersPerksStealthSpeechMerchant"
        Me.mnuModifiersPerksStealthSpeechMerchant.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechMerchant.Tag = "58f7a"
        Me.mnuModifiersPerksStealthSpeechMerchant.Text = "Merchant"
        '
        'mnuModifiersPerksStealthSpeechInvestor
        '
        Me.mnuModifiersPerksStealthSpeechInvestor.Name = "mnuModifiersPerksStealthSpeechInvestor"
        Me.mnuModifiersPerksStealthSpeechInvestor.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechInvestor.Tag = "58f7b"
        Me.mnuModifiersPerksStealthSpeechInvestor.Text = "Investor"
        '
        'mnuModifiersPerksStealthSpeechFence
        '
        Me.mnuModifiersPerksStealthSpeechFence.Name = "mnuModifiersPerksStealthSpeechFence"
        Me.mnuModifiersPerksStealthSpeechFence.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechFence.Tag = "58f79"
        Me.mnuModifiersPerksStealthSpeechFence.Text = "Fence"
        '
        'mnuModifiersPerksStealthSpeechMaster
        '
        Me.mnuModifiersPerksStealthSpeechMaster.Name = "mnuModifiersPerksStealthSpeechMaster"
        Me.mnuModifiersPerksStealthSpeechMaster.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechMaster.Tag = "1090a5"
        Me.mnuModifiersPerksStealthSpeechMaster.Text = "Master Trader"
        '
        'mnuModifiersPerksStealthSpeechBribe
        '
        Me.mnuModifiersPerksStealthSpeechBribe.Name = "mnuModifiersPerksStealthSpeechBribe"
        Me.mnuModifiersPerksStealthSpeechBribe.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechBribe.Tag = "58f72"
        Me.mnuModifiersPerksStealthSpeechBribe.Text = "Bribery"
        '
        'mnuModifiersPerksStealthSpeechPersuasion
        '
        Me.mnuModifiersPerksStealthSpeechPersuasion.Name = "mnuModifiersPerksStealthSpeechPersuasion"
        Me.mnuModifiersPerksStealthSpeechPersuasion.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechPersuasion.Tag = "1090a2"
        Me.mnuModifiersPerksStealthSpeechPersuasion.Text = "Persuasion"
        '
        'mnuModifiersPerksStealthSpeechIntimidation
        '
        Me.mnuModifiersPerksStealthSpeechIntimidation.Name = "mnuModifiersPerksStealthSpeechIntimidation"
        Me.mnuModifiersPerksStealthSpeechIntimidation.Size = New System.Drawing.Size(147, 22)
        Me.mnuModifiersPerksStealthSpeechIntimidation.Tag = "105f29"
        Me.mnuModifiersPerksStealthSpeechIntimidation.Text = "Intimidation"
        '
        'mnuModsPerksMagic
        '
        Me.mnuModsPerksMagic.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicAlteration, Me.mnuModifiersPerksMagicConjuration, Me.mnuModifiersPerksMagicDestruction, Me.mnuModifiersPerksMagicEnchanting, Me.mnuModifiersPerksMagicIllusion, Me.mnuModifiersPerksMagicRestoration})
        Me.mnuModsPerksMagic.Name = "mnuModsPerksMagic"
        Me.mnuModsPerksMagic.Size = New System.Drawing.Size(196, 22)
        Me.mnuModsPerksMagic.Text = "Magic"
        '
        'mnuModifiersPerksMagicAlteration
        '
        Me.mnuModifiersPerksMagicAlteration.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicAlterationNovice, Me.mnuModifiersPerksMagicAlterationDual, Me.mnuModifiersPerksMagicAlterationApprentice, Me.mnuModifiersPerksMagicAlterationMagicresist, Me.mnuModifiersPerksMagicAlterationAdept, Me.mnuModifiersPerksMagicAlterationExpert, Me.mnuModifiersPerksMagicAlterationAtronach, Me.mnuModifiersPerksMagicAlterationMaster, Me.mnuModifiersPerksMagicAlterationStability, Me.mnuModifiersPerksMagicAlterationMagearmor})
        Me.mnuModifiersPerksMagicAlteration.Name = "mnuModifiersPerksMagicAlteration"
        Me.mnuModifiersPerksMagicAlteration.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksMagicAlteration.Text = "Alteration"
        '
        'mnuModifiersPerksMagicAlterationNovice
        '
        Me.mnuModifiersPerksMagicAlterationNovice.Name = "mnuModifiersPerksMagicAlterationNovice"
        Me.mnuModifiersPerksMagicAlterationNovice.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationNovice.Tag = "f2ca6"
        Me.mnuModifiersPerksMagicAlterationNovice.Text = "Novice Alteration"
        '
        'mnuModifiersPerksMagicAlterationDual
        '
        Me.mnuModifiersPerksMagicAlterationDual.Name = "mnuModifiersPerksMagicAlterationDual"
        Me.mnuModifiersPerksMagicAlterationDual.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationDual.Tag = "153cd"
        Me.mnuModifiersPerksMagicAlterationDual.Text = "Alteration Dual Casting"
        '
        'mnuModifiersPerksMagicAlterationApprentice
        '
        Me.mnuModifiersPerksMagicAlterationApprentice.Name = "mnuModifiersPerksMagicAlterationApprentice"
        Me.mnuModifiersPerksMagicAlterationApprentice.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationApprentice.Tag = "c44b7"
        Me.mnuModifiersPerksMagicAlterationApprentice.Text = "Apprentice Alteration"
        '
        'mnuModifiersPerksMagicAlterationMagicresist
        '
        Me.mnuModifiersPerksMagicAlterationMagicresist.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicAlterationMagicresistRank1, Me.mnuModifiersPerksMagicAlterationMagicresistRank2, Me.mnuModifiersPerksMagicAlterationMagicresistRank3})
        Me.mnuModifiersPerksMagicAlterationMagicresist.Name = "mnuModifiersPerksMagicAlterationMagicresist"
        Me.mnuModifiersPerksMagicAlterationMagicresist.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationMagicresist.Text = "Magic Resistance"
        '
        'mnuModifiersPerksMagicAlterationMagicresistRank1
        '
        Me.mnuModifiersPerksMagicAlterationMagicresistRank1.Name = "mnuModifiersPerksMagicAlterationMagicresistRank1"
        Me.mnuModifiersPerksMagicAlterationMagicresistRank1.Size = New System.Drawing.Size(203, 22)
        Me.mnuModifiersPerksMagicAlterationMagicresistRank1.Tag = "53128"
        Me.mnuModifiersPerksMagicAlterationMagicresistRank1.Text = "Magic Resistance Rank 1"
        '
        'mnuModifiersPerksMagicAlterationMagicresistRank2
        '
        Me.mnuModifiersPerksMagicAlterationMagicresistRank2.Name = "mnuModifiersPerksMagicAlterationMagicresistRank2"
        Me.mnuModifiersPerksMagicAlterationMagicresistRank2.Size = New System.Drawing.Size(203, 22)
        Me.mnuModifiersPerksMagicAlterationMagicresistRank2.Tag = "53129"
        Me.mnuModifiersPerksMagicAlterationMagicresistRank2.Text = "Magic Resistance Rank 2"
        '
        'mnuModifiersPerksMagicAlterationMagicresistRank3
        '
        Me.mnuModifiersPerksMagicAlterationMagicresistRank3.Name = "mnuModifiersPerksMagicAlterationMagicresistRank3"
        Me.mnuModifiersPerksMagicAlterationMagicresistRank3.Size = New System.Drawing.Size(203, 22)
        Me.mnuModifiersPerksMagicAlterationMagicresistRank3.Tag = "5312a"
        Me.mnuModifiersPerksMagicAlterationMagicresistRank3.Text = "Magic Resistance Rank 3"
        '
        'mnuModifiersPerksMagicAlterationAdept
        '
        Me.mnuModifiersPerksMagicAlterationAdept.Name = "mnuModifiersPerksMagicAlterationAdept"
        Me.mnuModifiersPerksMagicAlterationAdept.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationAdept.Tag = "c44b8"
        Me.mnuModifiersPerksMagicAlterationAdept.Text = "Adept Alteration"
        '
        'mnuModifiersPerksMagicAlterationExpert
        '
        Me.mnuModifiersPerksMagicAlterationExpert.Name = "mnuModifiersPerksMagicAlterationExpert"
        Me.mnuModifiersPerksMagicAlterationExpert.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationExpert.Tag = "c44b9"
        Me.mnuModifiersPerksMagicAlterationExpert.Text = "Expert Alteration"
        '
        'mnuModifiersPerksMagicAlterationAtronach
        '
        Me.mnuModifiersPerksMagicAlterationAtronach.Name = "mnuModifiersPerksMagicAlterationAtronach"
        Me.mnuModifiersPerksMagicAlterationAtronach.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationAtronach.Tag = "581f7"
        Me.mnuModifiersPerksMagicAlterationAtronach.Text = "Atronach"
        '
        'mnuModifiersPerksMagicAlterationMaster
        '
        Me.mnuModifiersPerksMagicAlterationMaster.Name = "mnuModifiersPerksMagicAlterationMaster"
        Me.mnuModifiersPerksMagicAlterationMaster.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationMaster.Tag = "c44ba"
        Me.mnuModifiersPerksMagicAlterationMaster.Text = "Master Alteration"
        '
        'mnuModifiersPerksMagicAlterationStability
        '
        Me.mnuModifiersPerksMagicAlterationStability.Name = "mnuModifiersPerksMagicAlterationStability"
        Me.mnuModifiersPerksMagicAlterationStability.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationStability.Tag = "581fc"
        Me.mnuModifiersPerksMagicAlterationStability.Text = "Stability"
        '
        'mnuModifiersPerksMagicAlterationMagearmor
        '
        Me.mnuModifiersPerksMagicAlterationMagearmor.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicAlterationMagearmorRank1, Me.mnuModifiersPerksMagicAlterationMagearmorRank2, Me.mnuModifiersPerksMagicAlterationMagearmorRank3})
        Me.mnuModifiersPerksMagicAlterationMagearmor.Name = "mnuModifiersPerksMagicAlterationMagearmor"
        Me.mnuModifiersPerksMagicAlterationMagearmor.Size = New System.Drawing.Size(196, 22)
        Me.mnuModifiersPerksMagicAlterationMagearmor.Text = "Mage Armor"
        '
        'mnuModifiersPerksMagicAlterationMagearmorRank1
        '
        Me.mnuModifiersPerksMagicAlterationMagearmorRank1.Name = "mnuModifiersPerksMagicAlterationMagearmorRank1"
        Me.mnuModifiersPerksMagicAlterationMagearmorRank1.Size = New System.Drawing.Size(179, 22)
        Me.mnuModifiersPerksMagicAlterationMagearmorRank1.Tag = "d7999"
        Me.mnuModifiersPerksMagicAlterationMagearmorRank1.Text = "Mage Armor Rank 1"
        '
        'mnuModifiersPerksMagicAlterationMagearmorRank2
        '
        Me.mnuModifiersPerksMagicAlterationMagearmorRank2.Name = "mnuModifiersPerksMagicAlterationMagearmorRank2"
        Me.mnuModifiersPerksMagicAlterationMagearmorRank2.Size = New System.Drawing.Size(179, 22)
        Me.mnuModifiersPerksMagicAlterationMagearmorRank2.Tag = "d799a"
        Me.mnuModifiersPerksMagicAlterationMagearmorRank2.Text = "Mage Armor Rank 2"
        '
        'mnuModifiersPerksMagicAlterationMagearmorRank3
        '
        Me.mnuModifiersPerksMagicAlterationMagearmorRank3.Name = "mnuModifiersPerksMagicAlterationMagearmorRank3"
        Me.mnuModifiersPerksMagicAlterationMagearmorRank3.Size = New System.Drawing.Size(179, 22)
        Me.mnuModifiersPerksMagicAlterationMagearmorRank3.Tag = "d799b"
        Me.mnuModifiersPerksMagicAlterationMagearmorRank3.Text = "Mage Armor Rank 3"
        '
        'mnuModifiersPerksMagicConjuration
        '
        Me.mnuModifiersPerksMagicConjuration.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicConjurationNovice, Me.mnuModifiersPerksMagicConjurationApprentice, Me.mnuModifiersPerksMagicConjurationAdept, Me.mnuModifiersPerksMagicConjurationExpert, Me.mnuModifiersPerksMagicConjurationMaster, Me.mnuModifiersPerksMagicConjurationDual, Me.mnuModifiersPerksMagicConjurationMysticbind, Me.mnuModifiersPerksMagicConjurationSoulsteal, Me.mnuModifiersPerksMagicConjurationOblivbind, Me.mnuModifiersPerksMagicConjurationNecro, Me.mnuModifiersPerksMagicConjurationDark, Me.mnuModifiersPerksMagicConjurationSummoner, Me.mnuModifiersPerksMagicConjurationAtro, Me.mnuModifiersPerksMagicConjurationPotency, Me.mnuModifiersPerksMagicConjurationTwin})
        Me.mnuModifiersPerksMagicConjuration.Name = "mnuModifiersPerksMagicConjuration"
        Me.mnuModifiersPerksMagicConjuration.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksMagicConjuration.Text = "Conjuration"
        '
        'mnuModifiersPerksMagicConjurationNovice
        '
        Me.mnuModifiersPerksMagicConjurationNovice.Name = "mnuModifiersPerksMagicConjurationNovice"
        Me.mnuModifiersPerksMagicConjurationNovice.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationNovice.Tag = "f2ca7"
        Me.mnuModifiersPerksMagicConjurationNovice.Text = "Novice Conjuration"
        '
        'mnuModifiersPerksMagicConjurationApprentice
        '
        Me.mnuModifiersPerksMagicConjurationApprentice.Name = "mnuModifiersPerksMagicConjurationApprentice"
        Me.mnuModifiersPerksMagicConjurationApprentice.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationApprentice.Tag = "c44bb"
        Me.mnuModifiersPerksMagicConjurationApprentice.Text = "Apprentice Conjuration"
        '
        'mnuModifiersPerksMagicConjurationAdept
        '
        Me.mnuModifiersPerksMagicConjurationAdept.Name = "mnuModifiersPerksMagicConjurationAdept"
        Me.mnuModifiersPerksMagicConjurationAdept.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationAdept.Tag = "c44bc"
        Me.mnuModifiersPerksMagicConjurationAdept.Text = "Adept Conjuration"
        '
        'mnuModifiersPerksMagicConjurationExpert
        '
        Me.mnuModifiersPerksMagicConjurationExpert.Name = "mnuModifiersPerksMagicConjurationExpert"
        Me.mnuModifiersPerksMagicConjurationExpert.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationExpert.Tag = "c44bd"
        Me.mnuModifiersPerksMagicConjurationExpert.Text = "Expert Conjuration"
        '
        'mnuModifiersPerksMagicConjurationMaster
        '
        Me.mnuModifiersPerksMagicConjurationMaster.Name = "mnuModifiersPerksMagicConjurationMaster"
        Me.mnuModifiersPerksMagicConjurationMaster.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationMaster.Tag = "c44be"
        Me.mnuModifiersPerksMagicConjurationMaster.Text = "Master Conjuration"
        '
        'mnuModifiersPerksMagicConjurationDual
        '
        Me.mnuModifiersPerksMagicConjurationDual.Name = "mnuModifiersPerksMagicConjurationDual"
        Me.mnuModifiersPerksMagicConjurationDual.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationDual.Tag = "153ce"
        Me.mnuModifiersPerksMagicConjurationDual.Text = "Conjuration Dual Casting"
        '
        'mnuModifiersPerksMagicConjurationMysticbind
        '
        Me.mnuModifiersPerksMagicConjurationMysticbind.Name = "mnuModifiersPerksMagicConjurationMysticbind"
        Me.mnuModifiersPerksMagicConjurationMysticbind.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationMysticbind.Tag = "640b3"
        Me.mnuModifiersPerksMagicConjurationMysticbind.Text = "Mystic Binding"
        '
        'mnuModifiersPerksMagicConjurationSoulsteal
        '
        Me.mnuModifiersPerksMagicConjurationSoulsteal.Name = "mnuModifiersPerksMagicConjurationSoulsteal"
        Me.mnuModifiersPerksMagicConjurationSoulsteal.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationSoulsteal.Tag = "d799e"
        Me.mnuModifiersPerksMagicConjurationSoulsteal.Text = "Soul Stealer"
        '
        'mnuModifiersPerksMagicConjurationOblivbind
        '
        Me.mnuModifiersPerksMagicConjurationOblivbind.Name = "mnuModifiersPerksMagicConjurationOblivbind"
        Me.mnuModifiersPerksMagicConjurationOblivbind.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationOblivbind.Tag = "d799c"
        Me.mnuModifiersPerksMagicConjurationOblivbind.Text = "Oblivion Binding"
        '
        'mnuModifiersPerksMagicConjurationNecro
        '
        Me.mnuModifiersPerksMagicConjurationNecro.Name = "mnuModifiersPerksMagicConjurationNecro"
        Me.mnuModifiersPerksMagicConjurationNecro.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationNecro.Tag = "581dd"
        Me.mnuModifiersPerksMagicConjurationNecro.Text = "Necromancy"
        '
        'mnuModifiersPerksMagicConjurationDark
        '
        Me.mnuModifiersPerksMagicConjurationDark.Name = "mnuModifiersPerksMagicConjurationDark"
        Me.mnuModifiersPerksMagicConjurationDark.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationDark.Tag = "581de"
        Me.mnuModifiersPerksMagicConjurationDark.Text = "Dark Souls"
        '
        'mnuModifiersPerksMagicConjurationSummoner
        '
        Me.mnuModifiersPerksMagicConjurationSummoner.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicConjurationSummonerRank1, Me.mnuModifiersPerksMagicConjurationSummonerRank2})
        Me.mnuModifiersPerksMagicConjurationSummoner.Name = "mnuModifiersPerksMagicConjurationSummoner"
        Me.mnuModifiersPerksMagicConjurationSummoner.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationSummoner.Text = "Summoner"
        '
        'mnuModifiersPerksMagicConjurationSummonerRank1
        '
        Me.mnuModifiersPerksMagicConjurationSummonerRank1.Name = "mnuModifiersPerksMagicConjurationSummonerRank1"
        Me.mnuModifiersPerksMagicConjurationSummonerRank1.Size = New System.Drawing.Size(171, 22)
        Me.mnuModifiersPerksMagicConjurationSummonerRank1.Tag = "105f30"
        Me.mnuModifiersPerksMagicConjurationSummonerRank1.Text = "Summoner Rank 1"
        '
        'mnuModifiersPerksMagicConjurationSummonerRank2
        '
        Me.mnuModifiersPerksMagicConjurationSummonerRank2.Name = "mnuModifiersPerksMagicConjurationSummonerRank2"
        Me.mnuModifiersPerksMagicConjurationSummonerRank2.Size = New System.Drawing.Size(171, 22)
        Me.mnuModifiersPerksMagicConjurationSummonerRank2.Tag = "105f31"
        Me.mnuModifiersPerksMagicConjurationSummonerRank2.Text = "Summoner Rank 2"
        '
        'mnuModifiersPerksMagicConjurationAtro
        '
        Me.mnuModifiersPerksMagicConjurationAtro.Name = "mnuModifiersPerksMagicConjurationAtro"
        Me.mnuModifiersPerksMagicConjurationAtro.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationAtro.Tag = "cb419"
        Me.mnuModifiersPerksMagicConjurationAtro.Text = "Atromancy"
        '
        'mnuModifiersPerksMagicConjurationPotency
        '
        Me.mnuModifiersPerksMagicConjurationPotency.Name = "mnuModifiersPerksMagicConjurationPotency"
        Me.mnuModifiersPerksMagicConjurationPotency.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationPotency.Tag = "cb41a"
        Me.mnuModifiersPerksMagicConjurationPotency.Text = "Elemental Potency"
        '
        'mnuModifiersPerksMagicConjurationTwin
        '
        Me.mnuModifiersPerksMagicConjurationTwin.Name = "mnuModifiersPerksMagicConjurationTwin"
        Me.mnuModifiersPerksMagicConjurationTwin.Size = New System.Drawing.Size(207, 22)
        Me.mnuModifiersPerksMagicConjurationTwin.Tag = "d5f1c"
        Me.mnuModifiersPerksMagicConjurationTwin.Text = "Twin Souls"
        '
        'mnuModifiersPerksMagicDestruction
        '
        Me.mnuModifiersPerksMagicDestruction.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicDestructionNovice, Me.mnuModifiersPerksMagicDestructionApprentice, Me.mnuModifiersPerksMagicDestructionAdept, Me.mnuModifiersPerksMagicDestructionExpert, Me.mnuModifiersPerksMagicDestructionMaster, Me.mnuModifiersPerksMagicDestructionRune, Me.mnuModifiersPerksMagicDestructionAugmentflame, Me.mnuModifiersPerksMagicDestructionIntenseflame, Me.mnuModifiersPerksMagicDestructionAugmentfrost, Me.mnuModifiersPerksMagicDestructionDeepfreeze, Me.mnuModifiersPerksMagicDestructionAugmentshock, Me.mnuModifiersPerksMagicDestructionDisintigrate, Me.mnuModifiersPerksMagicDestructionDualcast, Me.mnuModifiersPerksMagicDestructionImpact})
        Me.mnuModifiersPerksMagicDestruction.Name = "mnuModifiersPerksMagicDestruction"
        Me.mnuModifiersPerksMagicDestruction.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksMagicDestruction.Text = "Destruction"
        '
        'mnuModifiersPerksMagicDestructionNovice
        '
        Me.mnuModifiersPerksMagicDestructionNovice.Name = "mnuModifiersPerksMagicDestructionNovice"
        Me.mnuModifiersPerksMagicDestructionNovice.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionNovice.Tag = "f2ca8"
        Me.mnuModifiersPerksMagicDestructionNovice.Text = "Novice Destruction"
        '
        'mnuModifiersPerksMagicDestructionApprentice
        '
        Me.mnuModifiersPerksMagicDestructionApprentice.Name = "mnuModifiersPerksMagicDestructionApprentice"
        Me.mnuModifiersPerksMagicDestructionApprentice.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionApprentice.Tag = "c44bf"
        Me.mnuModifiersPerksMagicDestructionApprentice.Text = "Apprentice Destruction"
        '
        'mnuModifiersPerksMagicDestructionAdept
        '
        Me.mnuModifiersPerksMagicDestructionAdept.Name = "mnuModifiersPerksMagicDestructionAdept"
        Me.mnuModifiersPerksMagicDestructionAdept.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionAdept.Tag = "c44c0"
        Me.mnuModifiersPerksMagicDestructionAdept.Text = "Adept Destruction"
        '
        'mnuModifiersPerksMagicDestructionExpert
        '
        Me.mnuModifiersPerksMagicDestructionExpert.Name = "mnuModifiersPerksMagicDestructionExpert"
        Me.mnuModifiersPerksMagicDestructionExpert.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionExpert.Tag = "c44c1"
        Me.mnuModifiersPerksMagicDestructionExpert.Text = "Expert Destruction"
        '
        'mnuModifiersPerksMagicDestructionMaster
        '
        Me.mnuModifiersPerksMagicDestructionMaster.Name = "mnuModifiersPerksMagicDestructionMaster"
        Me.mnuModifiersPerksMagicDestructionMaster.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionMaster.Tag = "c44c2"
        Me.mnuModifiersPerksMagicDestructionMaster.Text = "Master Destruction"
        '
        'mnuModifiersPerksMagicDestructionRune
        '
        Me.mnuModifiersPerksMagicDestructionRune.Name = "mnuModifiersPerksMagicDestructionRune"
        Me.mnuModifiersPerksMagicDestructionRune.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionRune.Tag = "105f32"
        Me.mnuModifiersPerksMagicDestructionRune.Text = "Rune Master"
        '
        'mnuModifiersPerksMagicDestructionAugmentflame
        '
        Me.mnuModifiersPerksMagicDestructionAugmentflame.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicDestructionAugmentflameRank1, Me.mnuModifiersPerksMagicDestructionAugmentflameRank2})
        Me.mnuModifiersPerksMagicDestructionAugmentflame.Name = "mnuModifiersPerksMagicDestructionAugmentflame"
        Me.mnuModifiersPerksMagicDestructionAugmentflame.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentflame.Text = "Augmented Flames"
        '
        'mnuModifiersPerksMagicDestructionAugmentflameRank1
        '
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank1.Name = "mnuModifiersPerksMagicDestructionAugmentflameRank1"
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank1.Size = New System.Drawing.Size(215, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank1.Tag = "581e7"
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank1.Text = "Augmented Flames Rank 1"
        '
        'mnuModifiersPerksMagicDestructionAugmentflameRank2
        '
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank2.Name = "mnuModifiersPerksMagicDestructionAugmentflameRank2"
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank2.Size = New System.Drawing.Size(215, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank2.Tag = "10fcf8"
        Me.mnuModifiersPerksMagicDestructionAugmentflameRank2.Text = "Augmented Flames Rank 2"
        '
        'mnuModifiersPerksMagicDestructionIntenseflame
        '
        Me.mnuModifiersPerksMagicDestructionIntenseflame.Name = "mnuModifiersPerksMagicDestructionIntenseflame"
        Me.mnuModifiersPerksMagicDestructionIntenseflame.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionIntenseflame.Tag = "f392e"
        Me.mnuModifiersPerksMagicDestructionIntenseflame.Text = "Intense Flames"
        '
        'mnuModifiersPerksMagicDestructionAugmentfrost
        '
        Me.mnuModifiersPerksMagicDestructionAugmentfrost.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicDestructionAugmentfrostRank1, Me.mnuModifiersPerksMagicDestructionAugmentfrostRank2})
        Me.mnuModifiersPerksMagicDestructionAugmentfrost.Name = "mnuModifiersPerksMagicDestructionAugmentfrost"
        Me.mnuModifiersPerksMagicDestructionAugmentfrost.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentfrost.Text = "Augmented Frost"
        '
        'mnuModifiersPerksMagicDestructionAugmentfrostRank1
        '
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank1.Name = "mnuModifiersPerksMagicDestructionAugmentfrostRank1"
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank1.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank1.Tag = "581ea"
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank1.Text = "Augmented Frost Rank 1"
        '
        'mnuModifiersPerksMagicDestructionAugmentfrostRank2
        '
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank2.Name = "mnuModifiersPerksMagicDestructionAugmentfrostRank2"
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank2.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank2.Tag = "10fcf9"
        Me.mnuModifiersPerksMagicDestructionAugmentfrostRank2.Text = "Augmented Frost Rank 2"
        '
        'mnuModifiersPerksMagicDestructionDeepfreeze
        '
        Me.mnuModifiersPerksMagicDestructionDeepfreeze.Name = "mnuModifiersPerksMagicDestructionDeepfreeze"
        Me.mnuModifiersPerksMagicDestructionDeepfreeze.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionDeepfreeze.Tag = "f3933"
        Me.mnuModifiersPerksMagicDestructionDeepfreeze.Text = "Deep Freeze"
        '
        'mnuModifiersPerksMagicDestructionAugmentshock
        '
        Me.mnuModifiersPerksMagicDestructionAugmentshock.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicDestructionAugmentshockRank1, Me.mnuModifiersPerksMagicDestructionAugmentshockRank2})
        Me.mnuModifiersPerksMagicDestructionAugmentshock.Name = "mnuModifiersPerksMagicDestructionAugmentshock"
        Me.mnuModifiersPerksMagicDestructionAugmentshock.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentshock.Text = "Augmented Shock"
        '
        'mnuModifiersPerksMagicDestructionAugmentshockRank1
        '
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank1.Name = "mnuModifiersPerksMagicDestructionAugmentshockRank1"
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank1.Size = New System.Drawing.Size(210, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank1.Tag = "58200"
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank1.Text = "Augmented Shock Rank 1"
        '
        'mnuModifiersPerksMagicDestructionAugmentshockRank2
        '
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank2.Name = "mnuModifiersPerksMagicDestructionAugmentshockRank2"
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank2.Size = New System.Drawing.Size(210, 22)
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank2.Tag = "10fcfa"
        Me.mnuModifiersPerksMagicDestructionAugmentshockRank2.Text = "Augmented Shock Rank 2"
        '
        'mnuModifiersPerksMagicDestructionDisintigrate
        '
        Me.mnuModifiersPerksMagicDestructionDisintigrate.Name = "mnuModifiersPerksMagicDestructionDisintigrate"
        Me.mnuModifiersPerksMagicDestructionDisintigrate.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionDisintigrate.Tag = "f3f0e"
        Me.mnuModifiersPerksMagicDestructionDisintigrate.Text = "Disintigrate"
        '
        'mnuModifiersPerksMagicDestructionDualcast
        '
        Me.mnuModifiersPerksMagicDestructionDualcast.Name = "mnuModifiersPerksMagicDestructionDualcast"
        Me.mnuModifiersPerksMagicDestructionDualcast.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionDualcast.Tag = "153cf"
        Me.mnuModifiersPerksMagicDestructionDualcast.Text = "Destruction Dual Casting"
        '
        'mnuModifiersPerksMagicDestructionImpact
        '
        Me.mnuModifiersPerksMagicDestructionImpact.Name = "mnuModifiersPerksMagicDestructionImpact"
        Me.mnuModifiersPerksMagicDestructionImpact.Size = New System.Drawing.Size(205, 22)
        Me.mnuModifiersPerksMagicDestructionImpact.Tag = "153d2"
        Me.mnuModifiersPerksMagicDestructionImpact.Text = "Impact"
        '
        'mnuModifiersPerksMagicEnchanting
        '
        Me.mnuModifiersPerksMagicEnchanting.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicEnchantingEnchanter, Me.mnuModifiersPerksMagicEnchantingFire, Me.mnuModifiersPerksMagicEnchantingFrost, Me.mnuModifiersPerksMagicEnchantingStorm, Me.mnuModifiersPerksMagicEnchantingInsight, Me.mnuModifiersPerksMagicEnchantingCorpus, Me.mnuModifiersPerksMagicEnchantingExtra, Me.mnuModifiersPerksMagicEnchantingSoulsqueeze, Me.mnuModifiersPerksMagicEnchantingSoulsiphon})
        Me.mnuModifiersPerksMagicEnchanting.Name = "mnuModifiersPerksMagicEnchanting"
        Me.mnuModifiersPerksMagicEnchanting.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksMagicEnchanting.Text = "Enchanting"
        '
        'mnuModifiersPerksMagicEnchantingEnchanter
        '
        Me.mnuModifiersPerksMagicEnchantingEnchanter.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicEnchantingEnchanterRank1, Me.mnuModifiersPerksMagicEnchantingEnchanterRank2, Me.mnuModifiersPerksMagicEnchantingEnchanterRank3, Me.mnuModifiersPerksMagicEnchantingEnchanterRank4, Me.mnuModifiersPerksMagicEnchantingEnchanterRank5})
        Me.mnuModifiersPerksMagicEnchantingEnchanter.Name = "mnuModifiersPerksMagicEnchantingEnchanter"
        Me.mnuModifiersPerksMagicEnchantingEnchanter.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingEnchanter.Text = "Enchanter"
        '
        'mnuModifiersPerksMagicEnchantingEnchanterRank1
        '
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank1.Name = "mnuModifiersPerksMagicEnchantingEnchanterRank1"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank1.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank1.Tag = "bee97"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank1.Text = "Enchanter Rank 1"
        '
        'mnuModifiersPerksMagicEnchantingEnchanterRank2
        '
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank2.Name = "mnuModifiersPerksMagicEnchantingEnchanterRank2"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank2.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank2.Tag = "c367c"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank2.Text = "Enchanter Rank 2"
        '
        'mnuModifiersPerksMagicEnchantingEnchanterRank3
        '
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank3.Name = "mnuModifiersPerksMagicEnchantingEnchanterRank3"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank3.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank3.Tag = "c367d"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank3.Text = "Enchanter Rank 3"
        '
        'mnuModifiersPerksMagicEnchantingEnchanterRank4
        '
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank4.Name = "mnuModifiersPerksMagicEnchantingEnchanterRank4"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank4.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank4.Tag = "c367e"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank4.Text = "Enchanter Rank 4"
        '
        'mnuModifiersPerksMagicEnchantingEnchanterRank5
        '
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank5.Name = "mnuModifiersPerksMagicEnchantingEnchanterRank5"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank5.Size = New System.Drawing.Size(165, 22)
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank5.Tag = "c367f"
        Me.mnuModifiersPerksMagicEnchantingEnchanterRank5.Text = "Enchanter Rank 5"
        '
        'mnuModifiersPerksMagicEnchantingFire
        '
        Me.mnuModifiersPerksMagicEnchantingFire.Name = "mnuModifiersPerksMagicEnchantingFire"
        Me.mnuModifiersPerksMagicEnchantingFire.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingFire.Tag = "58f80"
        Me.mnuModifiersPerksMagicEnchantingFire.Text = "Fire Enchanter"
        '
        'mnuModifiersPerksMagicEnchantingFrost
        '
        Me.mnuModifiersPerksMagicEnchantingFrost.Name = "mnuModifiersPerksMagicEnchantingFrost"
        Me.mnuModifiersPerksMagicEnchantingFrost.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingFrost.Tag = "58f81"
        Me.mnuModifiersPerksMagicEnchantingFrost.Text = "Frost Enchanter"
        '
        'mnuModifiersPerksMagicEnchantingStorm
        '
        Me.mnuModifiersPerksMagicEnchantingStorm.Name = "mnuModifiersPerksMagicEnchantingStorm"
        Me.mnuModifiersPerksMagicEnchantingStorm.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingStorm.Tag = "58f82"
        Me.mnuModifiersPerksMagicEnchantingStorm.Text = "Storm Enchanter"
        '
        'mnuModifiersPerksMagicEnchantingInsight
        '
        Me.mnuModifiersPerksMagicEnchantingInsight.Name = "mnuModifiersPerksMagicEnchantingInsight"
        Me.mnuModifiersPerksMagicEnchantingInsight.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingInsight.Tag = "58f7e"
        Me.mnuModifiersPerksMagicEnchantingInsight.Text = "Insightful Enchanter"
        '
        'mnuModifiersPerksMagicEnchantingCorpus
        '
        Me.mnuModifiersPerksMagicEnchantingCorpus.Name = "mnuModifiersPerksMagicEnchantingCorpus"
        Me.mnuModifiersPerksMagicEnchantingCorpus.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingCorpus.Tag = "58f7d"
        Me.mnuModifiersPerksMagicEnchantingCorpus.Text = "Corpus Enchanter"
        '
        'mnuModifiersPerksMagicEnchantingExtra
        '
        Me.mnuModifiersPerksMagicEnchantingExtra.Name = "mnuModifiersPerksMagicEnchantingExtra"
        Me.mnuModifiersPerksMagicEnchantingExtra.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingExtra.Tag = "58f7f"
        Me.mnuModifiersPerksMagicEnchantingExtra.Text = "Extra Effect"
        '
        'mnuModifiersPerksMagicEnchantingSoulsqueeze
        '
        Me.mnuModifiersPerksMagicEnchantingSoulsqueeze.Name = "mnuModifiersPerksMagicEnchantingSoulsqueeze"
        Me.mnuModifiersPerksMagicEnchantingSoulsqueeze.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingSoulsqueeze.Tag = "58f7c"
        Me.mnuModifiersPerksMagicEnchantingSoulsqueeze.Text = "Soul Squeezer"
        '
        'mnuModifiersPerksMagicEnchantingSoulsiphon
        '
        Me.mnuModifiersPerksMagicEnchantingSoulsiphon.Name = "mnuModifiersPerksMagicEnchantingSoulsiphon"
        Me.mnuModifiersPerksMagicEnchantingSoulsiphon.Size = New System.Drawing.Size(180, 22)
        Me.mnuModifiersPerksMagicEnchantingSoulsiphon.Tag = "108a44"
        Me.mnuModifiersPerksMagicEnchantingSoulsiphon.Text = "Soul Siphon"
        '
        'mnuModifiersPerksMagicIllusion
        '
        Me.mnuModifiersPerksMagicIllusion.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicIllusionNovice, Me.mnuModifiersPerksMagicIllusionAnimage, Me.mnuModifiersPerksMagicIllusionKindred, Me.mnuModifiersPerksMagicIllusionQuiet, Me.mnuModifiersPerksMagicIllusionApprentice, Me.mnuModifiersPerksMagicIllusionAdept, Me.mnuModifiersPerksMagicIllusionExpert, Me.mnuModifiersPerksMagicIllusionMaster, Me.mnuModifiersPerksMagicIllusionHypnotic, Me.mnuModifiersPerksMagicIllusionAspectterror, Me.mnuModifiersPerksMagicIllusionRage, Me.mnuModifiersPerksMagicIllusionMastermind, Me.mnuModifiersPerksMagicIllusionDual})
        Me.mnuModifiersPerksMagicIllusion.Name = "mnuModifiersPerksMagicIllusion"
        Me.mnuModifiersPerksMagicIllusion.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksMagicIllusion.Text = "Illusion"
        '
        'mnuModifiersPerksMagicIllusionNovice
        '
        Me.mnuModifiersPerksMagicIllusionNovice.Name = "mnuModifiersPerksMagicIllusionNovice"
        Me.mnuModifiersPerksMagicIllusionNovice.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionNovice.Tag = "f2ca9"
        Me.mnuModifiersPerksMagicIllusionNovice.Text = "Novice Illusion"
        '
        'mnuModifiersPerksMagicIllusionAnimage
        '
        Me.mnuModifiersPerksMagicIllusionAnimage.Name = "mnuModifiersPerksMagicIllusionAnimage"
        Me.mnuModifiersPerksMagicIllusionAnimage.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionAnimage.Tag = "581e1"
        Me.mnuModifiersPerksMagicIllusionAnimage.Text = "Animage"
        '
        'mnuModifiersPerksMagicIllusionKindred
        '
        Me.mnuModifiersPerksMagicIllusionKindred.Name = "mnuModifiersPerksMagicIllusionKindred"
        Me.mnuModifiersPerksMagicIllusionKindred.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionKindred.Tag = "581e2"
        Me.mnuModifiersPerksMagicIllusionKindred.Text = "Kindred Mage"
        '
        'mnuModifiersPerksMagicIllusionQuiet
        '
        Me.mnuModifiersPerksMagicIllusionQuiet.Name = "mnuModifiersPerksMagicIllusionQuiet"
        Me.mnuModifiersPerksMagicIllusionQuiet.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionQuiet.Tag = "581fd"
        Me.mnuModifiersPerksMagicIllusionQuiet.Text = "Quiet Casting"
        '
        'mnuModifiersPerksMagicIllusionApprentice
        '
        Me.mnuModifiersPerksMagicIllusionApprentice.Name = "mnuModifiersPerksMagicIllusionApprentice"
        Me.mnuModifiersPerksMagicIllusionApprentice.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionApprentice.Tag = "c44c3"
        Me.mnuModifiersPerksMagicIllusionApprentice.Text = "Apprentice Illusion"
        '
        'mnuModifiersPerksMagicIllusionAdept
        '
        Me.mnuModifiersPerksMagicIllusionAdept.Name = "mnuModifiersPerksMagicIllusionAdept"
        Me.mnuModifiersPerksMagicIllusionAdept.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionAdept.Tag = "c44c4"
        Me.mnuModifiersPerksMagicIllusionAdept.Text = "Adept Illusion"
        '
        'mnuModifiersPerksMagicIllusionExpert
        '
        Me.mnuModifiersPerksMagicIllusionExpert.Name = "mnuModifiersPerksMagicIllusionExpert"
        Me.mnuModifiersPerksMagicIllusionExpert.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionExpert.Tag = "c44c5"
        Me.mnuModifiersPerksMagicIllusionExpert.Text = "Expert Illusion"
        '
        'mnuModifiersPerksMagicIllusionMaster
        '
        Me.mnuModifiersPerksMagicIllusionMaster.Name = "mnuModifiersPerksMagicIllusionMaster"
        Me.mnuModifiersPerksMagicIllusionMaster.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionMaster.Tag = "c44c6"
        Me.mnuModifiersPerksMagicIllusionMaster.Text = "Master Illusion"
        '
        'mnuModifiersPerksMagicIllusionHypnotic
        '
        Me.mnuModifiersPerksMagicIllusionHypnotic.Name = "mnuModifiersPerksMagicIllusionHypnotic"
        Me.mnuModifiersPerksMagicIllusionHypnotic.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionHypnotic.Tag = "59b77"
        Me.mnuModifiersPerksMagicIllusionHypnotic.Text = "Hypnotic Gaze"
        '
        'mnuModifiersPerksMagicIllusionAspectterror
        '
        Me.mnuModifiersPerksMagicIllusionAspectterror.Name = "mnuModifiersPerksMagicIllusionAspectterror"
        Me.mnuModifiersPerksMagicIllusionAspectterror.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionAspectterror.Tag = "59b78"
        Me.mnuModifiersPerksMagicIllusionAspectterror.Text = "Aspect of Terror"
        '
        'mnuModifiersPerksMagicIllusionRage
        '
        Me.mnuModifiersPerksMagicIllusionRage.Name = "mnuModifiersPerksMagicIllusionRage"
        Me.mnuModifiersPerksMagicIllusionRage.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionRage.Tag = "c44b5"
        Me.mnuModifiersPerksMagicIllusionRage.Text = "Rage"
        '
        'mnuModifiersPerksMagicIllusionMastermind
        '
        Me.mnuModifiersPerksMagicIllusionMastermind.Name = "mnuModifiersPerksMagicIllusionMastermind"
        Me.mnuModifiersPerksMagicIllusionMastermind.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionMastermind.Tag = "59b76"
        Me.mnuModifiersPerksMagicIllusionMastermind.Text = "Master of the Mind"
        '
        'mnuModifiersPerksMagicIllusionDual
        '
        Me.mnuModifiersPerksMagicIllusionDual.Name = "mnuModifiersPerksMagicIllusionDual"
        Me.mnuModifiersPerksMagicIllusionDual.Size = New System.Drawing.Size(182, 22)
        Me.mnuModifiersPerksMagicIllusionDual.Tag = "153d0"
        Me.mnuModifiersPerksMagicIllusionDual.Text = "Illusion Dual Casting"
        '
        'mnuModifiersPerksMagicRestoration
        '
        Me.mnuModifiersPerksMagicRestoration.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicRestorationNovice, Me.mnuModifiersPerksMagicRestorationApprentice, Me.mnuModifiersPerksMagicRestorationAdept, Me.mnuModifiersPerksMagicRestorationExpert, Me.mnuModifiersPerksMagicRestorationMaster, Me.mnuModifiersPerksMagicRestorationRecovery, Me.mnuModifiersPerksMagicRestorationAvoiddeath, Me.mnuModifiersPerksMagicRestorationRegen, Me.mnuModifiersPerksMagicRestorationNecro, Me.mnuModifiersPerksMagicRestorationRespite, Me.mnuModifiersPerksMagicRestorationDual, Me.mnuModifiersPerksMagicRestorationWardabsorb})
        Me.mnuModifiersPerksMagicRestoration.Name = "mnuModifiersPerksMagicRestoration"
        Me.mnuModifiersPerksMagicRestoration.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersPerksMagicRestoration.Text = "Restoration"
        '
        'mnuModifiersPerksMagicRestorationNovice
        '
        Me.mnuModifiersPerksMagicRestorationNovice.Name = "mnuModifiersPerksMagicRestorationNovice"
        Me.mnuModifiersPerksMagicRestorationNovice.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationNovice.Tag = "f2caa"
        Me.mnuModifiersPerksMagicRestorationNovice.Text = "Novice Restoration"
        '
        'mnuModifiersPerksMagicRestorationApprentice
        '
        Me.mnuModifiersPerksMagicRestorationApprentice.Name = "mnuModifiersPerksMagicRestorationApprentice"
        Me.mnuModifiersPerksMagicRestorationApprentice.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationApprentice.Tag = "c44c7"
        Me.mnuModifiersPerksMagicRestorationApprentice.Text = "Apprentice Restoration"
        '
        'mnuModifiersPerksMagicRestorationAdept
        '
        Me.mnuModifiersPerksMagicRestorationAdept.Name = "mnuModifiersPerksMagicRestorationAdept"
        Me.mnuModifiersPerksMagicRestorationAdept.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationAdept.Tag = "c44c8"
        Me.mnuModifiersPerksMagicRestorationAdept.Text = "Adept Restoration"
        '
        'mnuModifiersPerksMagicRestorationExpert
        '
        Me.mnuModifiersPerksMagicRestorationExpert.Name = "mnuModifiersPerksMagicRestorationExpert"
        Me.mnuModifiersPerksMagicRestorationExpert.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationExpert.Tag = "c44c9"
        Me.mnuModifiersPerksMagicRestorationExpert.Text = "Expert Restoration"
        '
        'mnuModifiersPerksMagicRestorationMaster
        '
        Me.mnuModifiersPerksMagicRestorationMaster.Name = "mnuModifiersPerksMagicRestorationMaster"
        Me.mnuModifiersPerksMagicRestorationMaster.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationMaster.Tag = "c44ca"
        Me.mnuModifiersPerksMagicRestorationMaster.Text = "Master Restoration"
        '
        'mnuModifiersPerksMagicRestorationRecovery
        '
        Me.mnuModifiersPerksMagicRestorationRecovery.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersPerksMagicRestorationRecoveryRank1, Me.mnuModifiersPerksMagicRestorationRecoveryRank2})
        Me.mnuModifiersPerksMagicRestorationRecovery.Name = "mnuModifiersPerksMagicRestorationRecovery"
        Me.mnuModifiersPerksMagicRestorationRecovery.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationRecovery.Text = "Recovery"
        '
        'mnuModifiersPerksMagicRestorationRecoveryRank1
        '
        Me.mnuModifiersPerksMagicRestorationRecoveryRank1.Name = "mnuModifiersPerksMagicRestorationRecoveryRank1"
        Me.mnuModifiersPerksMagicRestorationRecoveryRank1.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksMagicRestorationRecoveryRank1.Tag = "581f4"
        Me.mnuModifiersPerksMagicRestorationRecoveryRank1.Text = "Recovery Rank 1"
        '
        'mnuModifiersPerksMagicRestorationRecoveryRank2
        '
        Me.mnuModifiersPerksMagicRestorationRecoveryRank2.Name = "mnuModifiersPerksMagicRestorationRecoveryRank2"
        Me.mnuModifiersPerksMagicRestorationRecoveryRank2.Size = New System.Drawing.Size(160, 22)
        Me.mnuModifiersPerksMagicRestorationRecoveryRank2.Tag = "581f5"
        Me.mnuModifiersPerksMagicRestorationRecoveryRank2.Text = "Recovery Rank 2"
        '
        'mnuModifiersPerksMagicRestorationAvoiddeath
        '
        Me.mnuModifiersPerksMagicRestorationAvoiddeath.Name = "mnuModifiersPerksMagicRestorationAvoiddeath"
        Me.mnuModifiersPerksMagicRestorationAvoiddeath.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationAvoiddeath.Tag = "a3f64"
        Me.mnuModifiersPerksMagicRestorationAvoiddeath.Text = "Avoid Death"
        '
        'mnuModifiersPerksMagicRestorationRegen
        '
        Me.mnuModifiersPerksMagicRestorationRegen.Name = "mnuModifiersPerksMagicRestorationRegen"
        Me.mnuModifiersPerksMagicRestorationRegen.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationRegen.Tag = "581f8"
        Me.mnuModifiersPerksMagicRestorationRegen.Text = "Regeneration"
        '
        'mnuModifiersPerksMagicRestorationNecro
        '
        Me.mnuModifiersPerksMagicRestorationNecro.Name = "mnuModifiersPerksMagicRestorationNecro"
        Me.mnuModifiersPerksMagicRestorationNecro.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationNecro.Tag = "581e4"
        Me.mnuModifiersPerksMagicRestorationNecro.Text = "Necromage"
        '
        'mnuModifiersPerksMagicRestorationRespite
        '
        Me.mnuModifiersPerksMagicRestorationRespite.Name = "mnuModifiersPerksMagicRestorationRespite"
        Me.mnuModifiersPerksMagicRestorationRespite.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationRespite.Tag = "581f9"
        Me.mnuModifiersPerksMagicRestorationRespite.Text = "Respite"
        '
        'mnuModifiersPerksMagicRestorationDual
        '
        Me.mnuModifiersPerksMagicRestorationDual.Name = "mnuModifiersPerksMagicRestorationDual"
        Me.mnuModifiersPerksMagicRestorationDual.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationDual.Tag = "153d1"
        Me.mnuModifiersPerksMagicRestorationDual.Text = "Restoration Dual Casting"
        '
        'mnuModifiersPerksMagicRestorationWardabsorb
        '
        Me.mnuModifiersPerksMagicRestorationWardabsorb.Name = "mnuModifiersPerksMagicRestorationWardabsorb"
        Me.mnuModifiersPerksMagicRestorationWardabsorb.Size = New System.Drawing.Size(204, 22)
        Me.mnuModifiersPerksMagicRestorationWardabsorb.Tag = "68bcc"
        Me.mnuModifiersPerksMagicRestorationWardabsorb.Text = "Ward Absorb"
        '
        'mnuModsCharlevel
        '
        Me.mnuModsCharlevel.Name = "mnuModsCharlevel"
        Me.mnuModsCharlevel.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsCharlevel.Text = "Character Level"
        '
        'mnuModsGold
        '
        Me.mnuModsGold.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsGoldAdd, Me.mnuModsGoldRemove})
        Me.mnuModsGold.Name = "mnuModsGold"
        Me.mnuModsGold.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsGold.Text = "Gold"
        '
        'mnuModsGoldAdd
        '
        Me.mnuModsGoldAdd.Name = "mnuModsGoldAdd"
        Me.mnuModsGoldAdd.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsGoldAdd.Text = "Add Gold"
        '
        'mnuModsGoldRemove
        '
        Me.mnuModsGoldRemove.Name = "mnuModsGoldRemove"
        Me.mnuModsGoldRemove.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsGoldRemove.Text = "Remove Gold"
        '
        'mnuModsHealth
        '
        Me.mnuModsHealth.Name = "mnuModsHealth"
        Me.mnuModsHealth.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsHealth.Text = "Health"
        '
        'mnuModsMagicka
        '
        Me.mnuModsMagicka.Name = "mnuModsMagicka"
        Me.mnuModsMagicka.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsMagicka.Text = "Magicka"
        '
        'mnuModsShouts
        '
        Me.mnuModsShouts.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsShoutsVanilla, Me.mnuModsShoutsDawnguard, Me.mnuModsShoutsDragonborn})
        Me.mnuModsShouts.Name = "mnuModsShouts"
        Me.mnuModsShouts.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsShouts.Text = "Shouts"
        '
        'mnuModsShoutsVanilla
        '
        Me.mnuModsShoutsVanilla.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsShoutsVanillaAnimal, Me.mnuModsShoutsVanillaAura, Me.mnuModsShoutsVanillaEthereal, Me.mnuModsShoutsVanillaCalldragon, Me.mnuModsShoutsVanillaCallvalor, Me.mnuModsShoutsVanillaClearskies, Me.mnuModsShoutsVanillaDisarm, Me.mnuModsShoutsVanillaDismay, Me.mnuModsShoutsVanillaDragonrend, Me.mnuModsShoutsVanillaElementalfury, Me.mnuModsShoutsVanillaFirebreath, Me.mnuModsShoutsVanillaFrostbreath, Me.mnuModsShoutsVanillaIceform, Me.mnuModsShoutsVanillaKynes, Me.mnuModsShoutsVanillaMarked, Me.mnuModsShoutsVanillaSlow, Me.mnuModsShoutsVanillaStorm, Me.mnuModsShoutsVanillaThrow, Me.mnuModsShoutsVanillaForce, Me.mnuModsShoutsVanillaSprint})
        Me.mnuModsShoutsVanilla.Name = "mnuModsShoutsVanilla"
        Me.mnuModsShoutsVanilla.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsShoutsVanilla.Text = "Vanilla"
        '
        'mnuModsShoutsVanillaAnimal
        '
        Me.mnuModsShoutsVanillaAnimal.Name = "mnuModsShoutsVanillaAnimal"
        Me.mnuModsShoutsVanillaAnimal.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaAnimal.Text = "Animal Allegiance"
        '
        'mnuModsShoutsVanillaAura
        '
        Me.mnuModsShoutsVanillaAura.Name = "mnuModsShoutsVanillaAura"
        Me.mnuModsShoutsVanillaAura.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaAura.Text = "Aura Whisper"
        '
        'mnuModsShoutsVanillaEthereal
        '
        Me.mnuModsShoutsVanillaEthereal.Name = "mnuModsShoutsVanillaEthereal"
        Me.mnuModsShoutsVanillaEthereal.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaEthereal.Text = "Become Ethereal"
        '
        'mnuModsShoutsVanillaCalldragon
        '
        Me.mnuModsShoutsVanillaCalldragon.Name = "mnuModsShoutsVanillaCalldragon"
        Me.mnuModsShoutsVanillaCalldragon.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaCalldragon.Text = "Call Dragon"
        '
        'mnuModsShoutsVanillaCallvalor
        '
        Me.mnuModsShoutsVanillaCallvalor.Name = "mnuModsShoutsVanillaCallvalor"
        Me.mnuModsShoutsVanillaCallvalor.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaCallvalor.Text = "Call of Valor"
        '
        'mnuModsShoutsVanillaClearskies
        '
        Me.mnuModsShoutsVanillaClearskies.Name = "mnuModsShoutsVanillaClearskies"
        Me.mnuModsShoutsVanillaClearskies.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaClearskies.Text = "Clear Skies"
        '
        'mnuModsShoutsVanillaDisarm
        '
        Me.mnuModsShoutsVanillaDisarm.Name = "mnuModsShoutsVanillaDisarm"
        Me.mnuModsShoutsVanillaDisarm.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaDisarm.Text = "Disarm"
        '
        'mnuModsShoutsVanillaDismay
        '
        Me.mnuModsShoutsVanillaDismay.Name = "mnuModsShoutsVanillaDismay"
        Me.mnuModsShoutsVanillaDismay.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaDismay.Text = "Dismay"
        '
        'mnuModsShoutsVanillaDragonrend
        '
        Me.mnuModsShoutsVanillaDragonrend.Name = "mnuModsShoutsVanillaDragonrend"
        Me.mnuModsShoutsVanillaDragonrend.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaDragonrend.Text = "Dragonrend"
        '
        'mnuModsShoutsVanillaElementalfury
        '
        Me.mnuModsShoutsVanillaElementalfury.Name = "mnuModsShoutsVanillaElementalfury"
        Me.mnuModsShoutsVanillaElementalfury.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaElementalfury.Text = "Elemental Fury"
        '
        'mnuModsShoutsVanillaFirebreath
        '
        Me.mnuModsShoutsVanillaFirebreath.Name = "mnuModsShoutsVanillaFirebreath"
        Me.mnuModsShoutsVanillaFirebreath.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaFirebreath.Text = "Fire Breath"
        '
        'mnuModsShoutsVanillaFrostbreath
        '
        Me.mnuModsShoutsVanillaFrostbreath.Name = "mnuModsShoutsVanillaFrostbreath"
        Me.mnuModsShoutsVanillaFrostbreath.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaFrostbreath.Text = "Frost Breath"
        '
        'mnuModsShoutsVanillaIceform
        '
        Me.mnuModsShoutsVanillaIceform.Name = "mnuModsShoutsVanillaIceform"
        Me.mnuModsShoutsVanillaIceform.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaIceform.Text = "Ice Form"
        '
        'mnuModsShoutsVanillaKynes
        '
        Me.mnuModsShoutsVanillaKynes.Name = "mnuModsShoutsVanillaKynes"
        Me.mnuModsShoutsVanillaKynes.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaKynes.Text = "Kyne's Peace"
        '
        'mnuModsShoutsVanillaMarked
        '
        Me.mnuModsShoutsVanillaMarked.Name = "mnuModsShoutsVanillaMarked"
        Me.mnuModsShoutsVanillaMarked.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaMarked.Text = "Marked for Death"
        '
        'mnuModsShoutsVanillaSlow
        '
        Me.mnuModsShoutsVanillaSlow.Name = "mnuModsShoutsVanillaSlow"
        Me.mnuModsShoutsVanillaSlow.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaSlow.Text = "Slow Time"
        '
        'mnuModsShoutsVanillaStorm
        '
        Me.mnuModsShoutsVanillaStorm.Name = "mnuModsShoutsVanillaStorm"
        Me.mnuModsShoutsVanillaStorm.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaStorm.Text = "Storm Call"
        '
        'mnuModsShoutsVanillaThrow
        '
        Me.mnuModsShoutsVanillaThrow.Name = "mnuModsShoutsVanillaThrow"
        Me.mnuModsShoutsVanillaThrow.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaThrow.Text = "Throw Voice"
        '
        'mnuModsShoutsVanillaForce
        '
        Me.mnuModsShoutsVanillaForce.Name = "mnuModsShoutsVanillaForce"
        Me.mnuModsShoutsVanillaForce.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaForce.Text = "Unrelenting Force"
        '
        'mnuModsShoutsVanillaSprint
        '
        Me.mnuModsShoutsVanillaSprint.Name = "mnuModsShoutsVanillaSprint"
        Me.mnuModsShoutsVanillaSprint.Size = New System.Drawing.Size(170, 22)
        Me.mnuModsShoutsVanillaSprint.Text = "Whirlwind Sprint"
        '
        'mnuModsShoutsDawnguard
        '
        Me.mnuModsShoutsDawnguard.Name = "mnuModsShoutsDawnguard"
        Me.mnuModsShoutsDawnguard.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsShoutsDawnguard.Text = "Dawnguard"
        Me.mnuModsShoutsDawnguard.Visible = False
        '
        'mnuModsShoutsDragonborn
        '
        Me.mnuModsShoutsDragonborn.Name = "mnuModsShoutsDragonborn"
        Me.mnuModsShoutsDragonborn.Size = New System.Drawing.Size(152, 22)
        Me.mnuModsShoutsDragonborn.Text = "Dragonborn"
        Me.mnuModsShoutsDragonborn.Visible = False
        '
        'mnuModsSkills
        '
        Me.mnuModsSkills.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersSkillsGroups, Me.mnuModifiersSkillsSpecific})
        Me.mnuModsSkills.Name = "mnuModsSkills"
        Me.mnuModsSkills.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsSkills.Text = "Skill Levels"
        '
        'mnuModifiersSkillsGroups
        '
        Me.mnuModifiersSkillsGroups.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersSkillsGroupsAll, Me.mnuModifiersSkillsGroupsCombat, Me.mnuModifiersSkillsGroupsStealth, Me.mnuModifiersSkillsGroupsMagic})
        Me.mnuModifiersSkillsGroups.Name = "mnuModifiersSkillsGroups"
        Me.mnuModifiersSkillsGroups.Size = New System.Drawing.Size(190, 22)
        Me.mnuModifiersSkillsGroups.Text = "Set Groups of Skills"
        '
        'mnuModifiersSkillsGroupsAll
        '
        Me.mnuModifiersSkillsGroupsAll.Name = "mnuModifiersSkillsGroupsAll"
        Me.mnuModifiersSkillsGroupsAll.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersSkillsGroupsAll.Text = "All 18 Skills"
        '
        'mnuModifiersSkillsGroupsCombat
        '
        Me.mnuModifiersSkillsGroupsCombat.Name = "mnuModifiersSkillsGroupsCombat"
        Me.mnuModifiersSkillsGroupsCombat.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersSkillsGroupsCombat.Text = "All 6 Combat Skills"
        '
        'mnuModifiersSkillsGroupsStealth
        '
        Me.mnuModifiersSkillsGroupsStealth.Name = "mnuModifiersSkillsGroupsStealth"
        Me.mnuModifiersSkillsGroupsStealth.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersSkillsGroupsStealth.Text = "All 6 Stealth Skills"
        '
        'mnuModifiersSkillsGroupsMagic
        '
        Me.mnuModifiersSkillsGroupsMagic.Name = "mnuModifiersSkillsGroupsMagic"
        Me.mnuModifiersSkillsGroupsMagic.Size = New System.Drawing.Size(172, 22)
        Me.mnuModifiersSkillsGroupsMagic.Text = "All 6 Magic Skills"
        '
        'mnuModifiersSkillsSpecific
        '
        Me.mnuModifiersSkillsSpecific.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersSkillsSpecificCombat, Me.mnuModifiersSkillsSpecificStealth, Me.mnuModifiersSkillsSpecificMagic})
        Me.mnuModifiersSkillsSpecific.Name = "mnuModifiersSkillsSpecific"
        Me.mnuModifiersSkillsSpecific.Size = New System.Drawing.Size(190, 22)
        Me.mnuModifiersSkillsSpecific.Text = "Choose a specific Skill"
        '
        'mnuModifiersSkillsSpecificCombat
        '
        Me.mnuModifiersSkillsSpecificCombat.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersSkillsSpecificCombatArchery, Me.mnuModifiersSkillsSpecificCombatBlock, Me.mnuModifiersSkillsSpecificCombatHeavyarmor, Me.mnuModifiersSkillsSpecificCombatOnehanded, Me.mnuModifiersSkillsSpecificCombatSmithing, Me.mnuModifiersSkillsSpecificCombatTwohanded})
        Me.mnuModifiersSkillsSpecificCombat.Name = "mnuModifiersSkillsSpecificCombat"
        Me.mnuModifiersSkillsSpecificCombat.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificCombat.Text = "Combat"
        '
        'mnuModifiersSkillsSpecificCombatArchery
        '
        Me.mnuModifiersSkillsSpecificCombatArchery.Name = "mnuModifiersSkillsSpecificCombatArchery"
        Me.mnuModifiersSkillsSpecificCombatArchery.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificCombatArchery.Tag = ""
        Me.mnuModifiersSkillsSpecificCombatArchery.Text = "Archery"
        '
        'mnuModifiersSkillsSpecificCombatBlock
        '
        Me.mnuModifiersSkillsSpecificCombatBlock.Name = "mnuModifiersSkillsSpecificCombatBlock"
        Me.mnuModifiersSkillsSpecificCombatBlock.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificCombatBlock.Tag = ""
        Me.mnuModifiersSkillsSpecificCombatBlock.Text = "Blocking"
        '
        'mnuModifiersSkillsSpecificCombatHeavyarmor
        '
        Me.mnuModifiersSkillsSpecificCombatHeavyarmor.Name = "mnuModifiersSkillsSpecificCombatHeavyarmor"
        Me.mnuModifiersSkillsSpecificCombatHeavyarmor.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificCombatHeavyarmor.Tag = ""
        Me.mnuModifiersSkillsSpecificCombatHeavyarmor.Text = "Heavy Armor"
        '
        'mnuModifiersSkillsSpecificCombatOnehanded
        '
        Me.mnuModifiersSkillsSpecificCombatOnehanded.Name = "mnuModifiersSkillsSpecificCombatOnehanded"
        Me.mnuModifiersSkillsSpecificCombatOnehanded.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificCombatOnehanded.Tag = ""
        Me.mnuModifiersSkillsSpecificCombatOnehanded.Text = "One Handed"
        '
        'mnuModifiersSkillsSpecificCombatSmithing
        '
        Me.mnuModifiersSkillsSpecificCombatSmithing.Name = "mnuModifiersSkillsSpecificCombatSmithing"
        Me.mnuModifiersSkillsSpecificCombatSmithing.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificCombatSmithing.Tag = ""
        Me.mnuModifiersSkillsSpecificCombatSmithing.Text = "Smithing"
        '
        'mnuModifiersSkillsSpecificCombatTwohanded
        '
        Me.mnuModifiersSkillsSpecificCombatTwohanded.Name = "mnuModifiersSkillsSpecificCombatTwohanded"
        Me.mnuModifiersSkillsSpecificCombatTwohanded.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificCombatTwohanded.Tag = ""
        Me.mnuModifiersSkillsSpecificCombatTwohanded.Text = "Two Handed"
        '
        'mnuModifiersSkillsSpecificStealth
        '
        Me.mnuModifiersSkillsSpecificStealth.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersSkillsSpecificStealthAlchemy, Me.mnuModifiersSkillsSpecificStealthLightarmor, Me.mnuModifiersSkillsSpecificStealthLockpicking, Me.mnuModifiersSkillsSpecificStealthPickpocket, Me.mnuModifiersSkillsSpecificStealthSneak, Me.mnuModifiersSkillsSpecificStealthSpeech})
        Me.mnuModifiersSkillsSpecificStealth.Name = "mnuModifiersSkillsSpecificStealth"
        Me.mnuModifiersSkillsSpecificStealth.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificStealth.Text = "Stealth"
        '
        'mnuModifiersSkillsSpecificStealthAlchemy
        '
        Me.mnuModifiersSkillsSpecificStealthAlchemy.Name = "mnuModifiersSkillsSpecificStealthAlchemy"
        Me.mnuModifiersSkillsSpecificStealthAlchemy.Size = New System.Drawing.Size(138, 22)
        Me.mnuModifiersSkillsSpecificStealthAlchemy.Tag = ""
        Me.mnuModifiersSkillsSpecificStealthAlchemy.Text = "Alchemy"
        '
        'mnuModifiersSkillsSpecificStealthLightarmor
        '
        Me.mnuModifiersSkillsSpecificStealthLightarmor.Name = "mnuModifiersSkillsSpecificStealthLightarmor"
        Me.mnuModifiersSkillsSpecificStealthLightarmor.Size = New System.Drawing.Size(138, 22)
        Me.mnuModifiersSkillsSpecificStealthLightarmor.Tag = ""
        Me.mnuModifiersSkillsSpecificStealthLightarmor.Text = "Light Armor"
        '
        'mnuModifiersSkillsSpecificStealthLockpicking
        '
        Me.mnuModifiersSkillsSpecificStealthLockpicking.Name = "mnuModifiersSkillsSpecificStealthLockpicking"
        Me.mnuModifiersSkillsSpecificStealthLockpicking.Size = New System.Drawing.Size(138, 22)
        Me.mnuModifiersSkillsSpecificStealthLockpicking.Tag = ""
        Me.mnuModifiersSkillsSpecificStealthLockpicking.Text = "Lockpicking"
        '
        'mnuModifiersSkillsSpecificStealthPickpocket
        '
        Me.mnuModifiersSkillsSpecificStealthPickpocket.Name = "mnuModifiersSkillsSpecificStealthPickpocket"
        Me.mnuModifiersSkillsSpecificStealthPickpocket.Size = New System.Drawing.Size(138, 22)
        Me.mnuModifiersSkillsSpecificStealthPickpocket.Tag = ""
        Me.mnuModifiersSkillsSpecificStealthPickpocket.Text = "Pickpocket"
        '
        'mnuModifiersSkillsSpecificStealthSneak
        '
        Me.mnuModifiersSkillsSpecificStealthSneak.Name = "mnuModifiersSkillsSpecificStealthSneak"
        Me.mnuModifiersSkillsSpecificStealthSneak.Size = New System.Drawing.Size(138, 22)
        Me.mnuModifiersSkillsSpecificStealthSneak.Text = "Sneak"
        '
        'mnuModifiersSkillsSpecificStealthSpeech
        '
        Me.mnuModifiersSkillsSpecificStealthSpeech.Name = "mnuModifiersSkillsSpecificStealthSpeech"
        Me.mnuModifiersSkillsSpecificStealthSpeech.Size = New System.Drawing.Size(138, 22)
        Me.mnuModifiersSkillsSpecificStealthSpeech.Text = "Speech"
        '
        'mnuModifiersSkillsSpecificMagic
        '
        Me.mnuModifiersSkillsSpecificMagic.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersSkillsSpecificMagicAlteration, Me.mnuModifiersSkillsSpecificMagicConjuration, Me.mnuModifiersSkillsSpecificMagicDestruction, Me.mnuModifiersSkillsSpecificMagicEnchanting, Me.mnuModifiersSkillsSpecificMagicIllusion, Me.mnuModifiersSkillsSpecificMagicRestoration})
        Me.mnuModifiersSkillsSpecificMagic.Name = "mnuModifiersSkillsSpecificMagic"
        Me.mnuModifiersSkillsSpecificMagic.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersSkillsSpecificMagic.Text = "Magic"
        '
        'mnuModifiersSkillsSpecificMagicAlteration
        '
        Me.mnuModifiersSkillsSpecificMagicAlteration.Name = "mnuModifiersSkillsSpecificMagicAlteration"
        Me.mnuModifiersSkillsSpecificMagicAlteration.Size = New System.Drawing.Size(137, 22)
        Me.mnuModifiersSkillsSpecificMagicAlteration.Text = "Alteration"
        '
        'mnuModifiersSkillsSpecificMagicConjuration
        '
        Me.mnuModifiersSkillsSpecificMagicConjuration.Name = "mnuModifiersSkillsSpecificMagicConjuration"
        Me.mnuModifiersSkillsSpecificMagicConjuration.Size = New System.Drawing.Size(137, 22)
        Me.mnuModifiersSkillsSpecificMagicConjuration.Text = "Conjuration"
        '
        'mnuModifiersSkillsSpecificMagicDestruction
        '
        Me.mnuModifiersSkillsSpecificMagicDestruction.Name = "mnuModifiersSkillsSpecificMagicDestruction"
        Me.mnuModifiersSkillsSpecificMagicDestruction.Size = New System.Drawing.Size(137, 22)
        Me.mnuModifiersSkillsSpecificMagicDestruction.Text = "Destruction"
        '
        'mnuModifiersSkillsSpecificMagicEnchanting
        '
        Me.mnuModifiersSkillsSpecificMagicEnchanting.Name = "mnuModifiersSkillsSpecificMagicEnchanting"
        Me.mnuModifiersSkillsSpecificMagicEnchanting.Size = New System.Drawing.Size(137, 22)
        Me.mnuModifiersSkillsSpecificMagicEnchanting.Text = "Enchanting"
        '
        'mnuModifiersSkillsSpecificMagicIllusion
        '
        Me.mnuModifiersSkillsSpecificMagicIllusion.Name = "mnuModifiersSkillsSpecificMagicIllusion"
        Me.mnuModifiersSkillsSpecificMagicIllusion.Size = New System.Drawing.Size(137, 22)
        Me.mnuModifiersSkillsSpecificMagicIllusion.Text = "Illusion"
        '
        'mnuModifiersSkillsSpecificMagicRestoration
        '
        Me.mnuModifiersSkillsSpecificMagicRestoration.Name = "mnuModifiersSkillsSpecificMagicRestoration"
        Me.mnuModifiersSkillsSpecificMagicRestoration.Size = New System.Drawing.Size(137, 22)
        Me.mnuModifiersSkillsSpecificMagicRestoration.Text = "Restoration"
        '
        'mnuModsStamina
        '
        Me.mnuModsStamina.Name = "mnuModsStamina"
        Me.mnuModsStamina.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsStamina.Text = "Stamina"
        '
        'mnuModsStone
        '
        Me.mnuModsStone.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModifiersStoneApprentice, Me.mnuModifiersStoneAtronach, Me.mnuModifiersStoneLady, Me.mnuModifiersStoneLord, Me.mnuModifiersStoneLover, Me.mnuModifiersStoneMage, Me.mnuModifiersStoneRitual, Me.mnuModifiersStoneSerpent, Me.mnuModifiersStoneShadow, Me.mnuModifiersStoneSteed, Me.mnuModifiersStoneThief, Me.mnuModifiersStoneTower, Me.mnuModifiersStoneWarrior})
        Me.mnuModsStone.Name = "mnuModsStone"
        Me.mnuModsStone.Size = New System.Drawing.Size(155, 22)
        Me.mnuModsStone.Text = "Stone Spells"
        '
        'mnuModifiersStoneApprentice
        '
        Me.mnuModifiersStoneApprentice.Name = "mnuModifiersStoneApprentice"
        Me.mnuModifiersStoneApprentice.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneApprentice.Tag = "e5f4e"
        Me.mnuModifiersStoneApprentice.Text = "Apprentice"
        '
        'mnuModifiersStoneAtronach
        '
        Me.mnuModifiersStoneAtronach.Name = "mnuModifiersStoneAtronach"
        Me.mnuModifiersStoneAtronach.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneAtronach.Tag = "e5f51"
        Me.mnuModifiersStoneAtronach.Text = "Atronach"
        '
        'mnuModifiersStoneLady
        '
        Me.mnuModifiersStoneLady.Name = "mnuModifiersStoneLady"
        Me.mnuModifiersStoneLady.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneLady.Tag = "e5f54"
        Me.mnuModifiersStoneLady.Text = "Lady"
        '
        'mnuModifiersStoneLord
        '
        Me.mnuModifiersStoneLord.Name = "mnuModifiersStoneLord"
        Me.mnuModifiersStoneLord.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneLord.Tag = "e5f58"
        Me.mnuModifiersStoneLord.Text = "Lord"
        '
        'mnuModifiersStoneLover
        '
        Me.mnuModifiersStoneLover.Name = "mnuModifiersStoneLover"
        Me.mnuModifiersStoneLover.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneLover.Tag = "e5f5a"
        Me.mnuModifiersStoneLover.Text = "Lover"
        '
        'mnuModifiersStoneMage
        '
        Me.mnuModifiersStoneMage.Name = "mnuModifiersStoneMage"
        Me.mnuModifiersStoneMage.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneMage.Tag = "e5f47"
        Me.mnuModifiersStoneMage.Text = "Mage"
        '
        'mnuModifiersStoneRitual
        '
        Me.mnuModifiersStoneRitual.Name = "mnuModifiersStoneRitual"
        Me.mnuModifiersStoneRitual.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneRitual.Tag = "e7329"
        Me.mnuModifiersStoneRitual.Text = "Ritual"
        '
        'mnuModifiersStoneSerpent
        '
        Me.mnuModifiersStoneSerpent.Name = "mnuModifiersStoneSerpent"
        Me.mnuModifiersStoneSerpent.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneSerpent.Tag = "e5f61"
        Me.mnuModifiersStoneSerpent.Text = "Serpent"
        '
        'mnuModifiersStoneShadow
        '
        Me.mnuModifiersStoneShadow.Name = "mnuModifiersStoneShadow"
        Me.mnuModifiersStoneShadow.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneShadow.Tag = "e732a"
        Me.mnuModifiersStoneShadow.Text = "Shadow"
        '
        'mnuModifiersStoneSteed
        '
        Me.mnuModifiersStoneSteed.Name = "mnuModifiersStoneSteed"
        Me.mnuModifiersStoneSteed.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneSteed.Tag = "e5f5e"
        Me.mnuModifiersStoneSteed.Text = "Steed"
        '
        'mnuModifiersStoneThief
        '
        Me.mnuModifiersStoneThief.Name = "mnuModifiersStoneThief"
        Me.mnuModifiersStoneThief.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneThief.Tag = "e5f45"
        Me.mnuModifiersStoneThief.Text = "Thief"
        '
        'mnuModifiersStoneTower
        '
        Me.mnuModifiersStoneTower.Name = "mnuModifiersStoneTower"
        Me.mnuModifiersStoneTower.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneTower.Tag = "e7328"
        Me.mnuModifiersStoneTower.Text = "Tower"
        '
        'mnuModifiersStoneWarrior
        '
        Me.mnuModifiersStoneWarrior.Name = "mnuModifiersStoneWarrior"
        Me.mnuModifiersStoneWarrior.Size = New System.Drawing.Size(152, 22)
        Me.mnuModifiersStoneWarrior.Tag = "e5f4c"
        Me.mnuModifiersStoneWarrior.Text = "Warrior"
        '
        'mnuModes
        '
        Me.mnuModes.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModesStandard, Me.mnuModesAdvanced})
        Me.mnuModes.Name = "mnuModes"
        Me.mnuModes.Size = New System.Drawing.Size(55, 20)
        Me.mnuModes.Text = "Modes"
        '
        'mnuModesStandard
        '
        Me.mnuModesStandard.Checked = True
        Me.mnuModesStandard.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuModesStandard.Name = "mnuModesStandard"
        Me.mnuModesStandard.Size = New System.Drawing.Size(152, 22)
        Me.mnuModesStandard.Text = "Standard"
        '
        'mnuModesAdvanced
        '
        Me.mnuModesAdvanced.Name = "mnuModesAdvanced"
        Me.mnuModesAdvanced.Size = New System.Drawing.Size(152, 22)
        Me.mnuModesAdvanced.Text = "Advanced"
        '
        'mnuDLC
        '
        Me.mnuDLC.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDLCVanilla, Me.mnuDLCDawnguard, Me.mnuDLCDragonborn})
        Me.mnuDLC.Name = "mnuDLC"
        Me.mnuDLC.Size = New System.Drawing.Size(41, 20)
        Me.mnuDLC.Text = "DLC"
        '
        'mnuDLCVanilla
        '
        Me.mnuDLCVanilla.Checked = True
        Me.mnuDLCVanilla.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuDLCVanilla.Name = "mnuDLCVanilla"
        Me.mnuDLCVanilla.Size = New System.Drawing.Size(152, 22)
        Me.mnuDLCVanilla.Text = "Vanilla"
        '
        'mnuDLCDawnguard
        '
        Me.mnuDLCDawnguard.Name = "mnuDLCDawnguard"
        Me.mnuDLCDawnguard.Size = New System.Drawing.Size(152, 22)
        Me.mnuDLCDawnguard.Text = "Dawnguard"
        '
        'mnuDLCDragonborn
        '
        Me.mnuDLCDragonborn.Name = "mnuDLCDragonborn"
        Me.mnuDLCDragonborn.Size = New System.Drawing.Size(152, 22)
        Me.mnuDLCDragonborn.Text = "Dragonborn"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpAbout, Me.mnuHelpInstructions})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mnuHelp.Text = "Help"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Name = "mnuHelpAbout"
        Me.mnuHelpAbout.Size = New System.Drawing.Size(181, 22)
        Me.mnuHelpAbout.Text = "About This Program"
        '
        'mnuHelpInstructions
        '
        Me.mnuHelpInstructions.Name = "mnuHelpInstructions"
        Me.mnuHelpInstructions.Size = New System.Drawing.Size(181, 22)
        Me.mnuHelpInstructions.Text = "Instructions"
        '
        'ListView
        '
        Me.ListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lvwCode, Me.lvwDescription})
        Me.ListView.FullRowSelect = True
        ListViewGroup1.Header = "ListViewGroup"
        ListViewGroup1.Name = "ListViewGroup1"
        Me.ListView.Groups.AddRange(New System.Windows.Forms.ListViewGroup() {ListViewGroup1})
        Me.ListView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.ListView.LabelWrap = False
        Me.ListView.Location = New System.Drawing.Point(12, 73)
        Me.ListView.MultiSelect = False
        Me.ListView.Name = "ListView"
        Me.ListView.ShowGroups = False
        Me.ListView.Size = New System.Drawing.Size(317, 289)
        Me.ListView.TabIndex = 21
        Me.ListView.UseCompatibleStateImageBehavior = False
        Me.ListView.View = System.Windows.Forms.View.Details
        '
        'lvwCode
        '
        Me.lvwCode.Text = "Code"
        Me.lvwCode.Width = 150
        '
        'lvwDescription
        '
        Me.lvwDescription.Text = "Description"
        Me.lvwDescription.Width = 400
        '
        'mnuModsPerksWerewolf
        '
        Me.mnuModsPerksWerewolf.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksWerewolfBestialstrength, Me.mnuModsPerksWerewolfAnimalvigor, Me.mnuModsPerksWerewolfGorging, Me.mnuModsPerksWerewolfSavagefeeding, Me.mnuModsPerksWerewolfTotemice, Me.mnuModsPerksWerewolfTotemmoon, Me.mnuModsPerksWerewolfTotemterror, Me.mnuModsPerksWerewolfTotempredator})
        Me.mnuModsPerksWerewolf.Name = "mnuModsPerksWerewolf"
        Me.mnuModsPerksWerewolf.Size = New System.Drawing.Size(196, 22)
        Me.mnuModsPerksWerewolf.Text = "Werewolf (Dawnguard)"
        Me.mnuModsPerksWerewolf.Visible = False
        '
        'mnuModsPerksWerewolfBestialstrength
        '
        Me.mnuModsPerksWerewolfBestialstrength.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuModsPerksWerewolfBestialstrengthRank1, Me.mnuModsPerksWerewolfBestialstrengthRank2, Me.mnuModsPerksWerewolfBestialstrengthRank3, Me.mnuModsPerksWerewolfBestialstrengthRank4})
        Me.mnuModsPerksWerewolfBestialstrength.Name = "mnuModsPerksWerewolfBestialstrength"
        Me.mnuModsPerksWerewolfBestialstrength.Size = New System.Drawing.Size(191, 22)
        Me.mnuModsPerksWerewolfBestialstrength.Text = "Bestial Strength"
        '
        'mnuModsPerksWerewolfAnimalvigor
        '
        Me.mnuModsPerksWerewolfAnimalvigor.Name = "mnuModsPerksWerewolfAnimalvigor"
        Me.mnuModsPerksWerewolfAnimalvigor.Size = New System.Drawing.Size(191, 22)
        Me.mnuModsPerksWerewolfAnimalvigor.Tag = "0059a5"
        Me.mnuModsPerksWerewolfAnimalvigor.Text = "Animal Vigor"
        '
        'mnuModsPerksWerewolfGorging
        '
        Me.mnuModsPerksWerewolfGorging.Name = "mnuModsPerksWerewolfGorging"
        Me.mnuModsPerksWerewolfGorging.Size = New System.Drawing.Size(191, 22)
        Me.mnuModsPerksWerewolfGorging.Tag = "0059a7"
        Me.mnuModsPerksWerewolfGorging.Text = "Gorging"
        '
        'mnuModsPerksWerewolfSavagefeeding
        '
        Me.mnuModsPerksWerewolfSavagefeeding.Name = "mnuModsPerksWerewolfSavagefeeding"
        Me.mnuModsPerksWerewolfSavagefeeding.Size = New System.Drawing.Size(191, 22)
        Me.mnuModsPerksWerewolfSavagefeeding.Tag = "0059a6"
        Me.mnuModsPerksWerewolfSavagefeeding.Text = "Savage Feeding"
        '
        'mnuModsPerksWerewolfTotemice
        '
        Me.mnuModsPerksWerewolfTotemice.Name = "mnuModsPerksWerewolfTotemice"
        Me.mnuModsPerksWerewolfTotemice.Size = New System.Drawing.Size(191, 22)
        Me.mnuModsPerksWerewolfTotemice.Tag = "0059aa"
        Me.mnuModsPerksWerewolfTotemice.Text = "Totem of Ice Brothers"
        '
        'mnuModsPerksWerewolfTotemmoon
        '
        Me.mnuModsPerksWerewolfTotemmoon.Name = "mnuModsPerksWerewolfTotemmoon"
        Me.mnuModsPerksWerewolfTotemmoon.Size = New System.Drawing.Size(191, 22)
        Me.mnuModsPerksWerewolfTotemmoon.Tag = "0059ab"
        Me.mnuModsPerksWerewolfTotemmoon.Text = "Totem of the Moon"
        '
        'mnuModsPerksWerewolfTotemterror
        '
        Me.mnuModsPerksWerewolfTotemterror.Name = "mnuModsPerksWerewolfTotemterror"
        Me.mnuModsPerksWerewolfTotemterror.Size = New System.Drawing.Size(191, 22)
        Me.mnuModsPerksWerewolfTotemterror.Tag = "0059a8"
        Me.mnuModsPerksWerewolfTotemterror.Text = "Totem of Terror"
        '
        'mnuModsPerksWerewolfTotempredator
        '
        Me.mnuModsPerksWerewolfTotempredator.Name = "mnuModsPerksWerewolfTotempredator"
        Me.mnuModsPerksWerewolfTotempredator.Size = New System.Drawing.Size(191, 22)
        Me.mnuModsPerksWerewolfTotempredator.Tag = "0059a9"
        Me.mnuModsPerksWerewolfTotempredator.Text = "Totem of the Predator"
        '
        'mnuModsPerksWerewolfBestialstrengthRank1
        '
        Me.mnuModsPerksWerewolfBestialstrengthRank1.Name = "mnuModsPerksWerewolfBestialstrengthRank1"
        Me.mnuModsPerksWerewolfBestialstrengthRank1.Size = New System.Drawing.Size(194, 22)
        Me.mnuModsPerksWerewolfBestialstrengthRank1.Tag = "0059a4"
        Me.mnuModsPerksWerewolfBestialstrengthRank1.Text = "Bestial Strength Rank 1"
        '
        'mnuModsPerksWerewolfBestialstrengthRank2
        '
        Me.mnuModsPerksWerewolfBestialstrengthRank2.Name = "mnuModsPerksWerewolfBestialstrengthRank2"
        Me.mnuModsPerksWerewolfBestialstrengthRank2.Size = New System.Drawing.Size(194, 22)
        Me.mnuModsPerksWerewolfBestialstrengthRank2.Tag = "007a3f"
        Me.mnuModsPerksWerewolfBestialstrengthRank2.Text = "Bestial Strength Rank 2"
        '
        'mnuModsPerksWerewolfBestialstrengthRank3
        '
        Me.mnuModsPerksWerewolfBestialstrengthRank3.Name = "mnuModsPerksWerewolfBestialstrengthRank3"
        Me.mnuModsPerksWerewolfBestialstrengthRank3.Size = New System.Drawing.Size(194, 22)
        Me.mnuModsPerksWerewolfBestialstrengthRank3.Tag = "011cfa"
        Me.mnuModsPerksWerewolfBestialstrengthRank3.Text = "Bestial Strength Rank 3"
        '
        'mnuModsPerksWerewolfBestialstrengthRank4
        '
        Me.mnuModsPerksWerewolfBestialstrengthRank4.Name = "mnuModsPerksWerewolfBestialstrengthRank4"
        Me.mnuModsPerksWerewolfBestialstrengthRank4.Size = New System.Drawing.Size(194, 22)
        Me.mnuModsPerksWerewolfBestialstrengthRank4.Tag = "011cfb"
        Me.mnuModsPerksWerewolfBestialstrengthRank4.Text = "Bestial Strength Rank 4"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(341, 374)
        Me.Controls.Add(Me.ListView)
        Me.Controls.Add(Me.txtPreview)
        Me.Controls.Add(Me.txtBatchName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.mnuStrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnuStrip
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Skyrim Batch Generator"
        Me.mnuStrip.ResumeLayout(False)
        Me.mnuStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtBatchName As System.Windows.Forms.TextBox
    Friend WithEvents txtPreview As System.Windows.Forms.TextBox
    Friend WithEvents mnuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileCreateBatch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileStartOver As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuMods As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsCharlevel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsGold As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsHealth As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsMagicka As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerks As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsSkills As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsStamina As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsStone As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsGoldAdd As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsGoldRemove As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsGroups As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecific As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsGroupsAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsGroupsCombat As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsGroupsStealth As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsGroupsMagic As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificCombat As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificStealth As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificMagic As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificCombatArchery As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificCombatBlock As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificCombatHeavyarmor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificCombatOnehanded As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificCombatSmithing As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificCombatTwohanded As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificStealthAlchemy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificStealthLightarmor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificStealthLockpicking As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificStealthPickpocket As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificStealthSneak As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificStealthSpeech As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificMagicAlteration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificMagicConjuration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificMagicDestruction As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificMagicEnchanting As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificMagicIllusion As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersSkillsSpecificMagicRestoration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombat As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArchery As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlocking As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatOnehanded As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatSmithing As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatTwohanded As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksStealth As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpicking As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocket As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneak As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeech As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksMagic As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlteration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjuration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestruction As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchanting As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusion As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestoration As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryOverdraw As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryCriticalshot As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryHuntersdiscipline As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryRanger As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryEagleeye As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryPowershot As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryQuickshot As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcherySteadyhand As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryBullseye As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingShieldwall As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingDeflectarrows As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingElementalprotection As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingBlockrunner As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingPowerbash As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingDeadlybash As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingDisarmingbash As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingShieldcharge As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingQuickreflexes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorJuggernaut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorFistsofsteel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorCushioned As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorConditioning As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorWellfitted As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorTowerofstrength As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorMatchingset As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorReflectblows As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedArmsman As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedBladesman As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedBonebreaker As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedDualflurry As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedDualsavagery As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedFightingstance As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedCriticalcharge As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedSavagestrike As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedParalyzingstrike As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryOverdrawRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryOverdrawRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryOverdrawRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryOverdrawRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryOverdrawRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryCriticalshotRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryCriticalshotRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcheryCriticalshotRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcherySteadyhandRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatArcherySteadyhandRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingShieldwallRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingShieldwallRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingShieldwallRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingShieldwallRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatBlockingShieldwallRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorJuggernautRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorJuggernautRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorJuggernautRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorJuggernautRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksCombatHeavyarmorJuggernautRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedArmsmanRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedArmsmanRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedArmsmanRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedArmsmanRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedArmsmanRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedBladesmanRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedBladesmanRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedBladesmanRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedBonebreakerRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedBonebreakerRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedBonebreakerRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedDualflurryRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedDualflurryRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedHackandslash As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedHackandslashRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedHackandslashRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatOnehandedHackandslashRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingSteel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingArcane As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingDwarven As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingOrcish As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingEbony As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingDaedric As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingElven As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingAdvanced As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingGlass As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatSmithingDragon As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedBarbarian As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedBarbarianRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedBarbarianRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedBarbarianRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedBarbarianRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedBarbarianRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedChampionstance As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedDevastatingblow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedGreatcritcharge As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedSweep As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedWarmaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedDeepwounds As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedDeepwoundsRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedDeepwoundsRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedDeepwoundsRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedLimbsplitter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedLimbsplitterRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedLimbsplitterRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedLimbsplitterRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedSkullcrusher As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedSkullcrusherRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedSkullcrusherRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksCombatTwohandedSkullcrusherRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyAlchemist As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyAlchemistRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyAlchemistRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyAlchemistRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyAlchemistRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyAlchemistRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyPhysician As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyBenefactor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyExperimenter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyExperimenterRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyExperimenterRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyExperimenterRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyPoisoner As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyConcpoison As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyGreenthumb As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemySnakeblood As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthAlchemyPurity As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorAgiledefender As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorAgiledefenderRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorAgiledefenderRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorAgiledefenderRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorAgiledefenderRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorAgiledefenderRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorCustomfit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorMatchset As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorUnhindered As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorWind As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLightarmorDeftmove As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingNovice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingApprentice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingQuickhands As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingWaxkey As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingAdept As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingExpert As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingGoldtouch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingTreasure As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingLocksmith As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingUnbreakable As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthLockpickingMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketLightfingers As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketLightfingersRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketLightfingersRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketLightfingersRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketLightfingersRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketLightfingersRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketNight As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketCutpurse As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketKeymaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketMisdirection As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketPerfecttouch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketExtrapockets As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthPickpocketPoisoned As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakStealth As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakStealthRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakStealthRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakStealthRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakStealthRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakStealthRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakBackstab As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakDeadlyaim As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakAssblade As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakMufflemove As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakLightfoot As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakSilentroll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakSilence As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSneakShadow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechHaggle As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechHaggleRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechHaggleRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechHaggleRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechHaggleRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechHaggleRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechAllure As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechMerchant As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechInvestor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechFence As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechBribe As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechPersuasion As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksStealthSpeechIntimidation As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationNovice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationDual As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationApprentice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMagicresist As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMagicresistRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMagicresistRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMagicresistRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationAdept As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationExpert As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationAtronach As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationStability As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMagearmor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMagearmorRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMagearmorRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicAlterationMagearmorRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationNovice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationApprentice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationAdept As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationExpert As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationDual As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationMysticbind As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationSoulsteal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationOblivbind As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationNecro As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationDark As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationSummoner As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationSummonerRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationSummonerRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationAtro As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationPotency As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicConjurationTwin As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionNovice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionApprentice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAdept As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionExpert As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionRune As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentflame As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentflameRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentflameRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionIntenseflame As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentfrost As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentfrostRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentfrostRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionDeepfreeze As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentshock As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentshockRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionAugmentshockRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionDisintigrate As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionDualcast As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicDestructionImpact As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingEnchanter As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingEnchanterRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingEnchanterRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingEnchanterRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingEnchanterRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingEnchanterRank5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingFire As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingFrost As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingStorm As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingInsight As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingCorpus As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingExtra As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingSoulsqueeze As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicEnchantingSoulsiphon As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionNovice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionAnimage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionKindred As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionQuiet As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionApprentice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionAdept As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionExpert As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionHypnotic As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionAspectterror As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionRage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionMastermind As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicIllusionDual As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationNovice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationApprentice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationAdept As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationExpert As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationMaster As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationRecovery As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationAvoiddeath As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationRegen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationNecro As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationRespite As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationDual As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationWardabsorb As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationRecoveryRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersPerksMagicRestorationRecoveryRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListView As System.Windows.Forms.ListView
    Friend WithEvents lvwCode As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvwDescription As System.Windows.Forms.ColumnHeader
    Friend WithEvents mnuHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelpAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelpInstructions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneApprentice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneAtronach As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneLady As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneLord As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneLover As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneMage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneRitual As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneSerpent As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneShadow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneSteed As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneThief As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneTower As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModifiersStoneWarrior As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModesStandard As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModesAdvanced As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDLC As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDLCVanilla As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDLCDawnguard As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuDLCDragonborn As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShouts As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanilla As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaAnimal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaAura As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaEthereal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaCalldragon As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaCallvalor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaClearskies As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaDisarm As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaDismay As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaDragonrend As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaElementalfury As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaFirebreath As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaFrostbreath As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaIceform As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaKynes As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaMarked As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaSlow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaStorm As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaThrow As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaForce As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsVanillaSprint As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsDawnguard As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsShoutsDragonborn As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolf As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfBestialstrength As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfBestialstrengthRank1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfBestialstrengthRank2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfBestialstrengthRank3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfBestialstrengthRank4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfAnimalvigor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfGorging As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfSavagefeeding As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfTotemice As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfTotemmoon As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfTotemterror As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuModsPerksWerewolfTotempredator As System.Windows.Forms.ToolStripMenuItem

End Class
